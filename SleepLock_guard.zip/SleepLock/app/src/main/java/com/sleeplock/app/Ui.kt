package com.sleeplock.app

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import android.os.Build
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

class UiState {
    var sec by mutableIntStateOf(0)
    var entered by mutableStateOf("")
    var error by mutableStateOf(false)
    var battery by mutableIntStateOf(-1)     // % заряда, -1 = неизвестно
    var charging by mutableStateOf(false)
    var extraLeft by mutableIntStateOf(0)           // секунды до конца "Ещё 10 минут"
    var extraAvailable by mutableStateOf(false)     // можно ли ещё нажать кнопку
    var wifiOn by mutableStateOf(false)
    var btOn by mutableStateOf(false)
}

private val NightColors = darkColorScheme(
    primary = Color(0xFFB8C4FF),
    onPrimary = Color(0xFF1B2D7A),
    primaryContainer = Color(0xFF334290),
    onPrimaryContainer = Color(0xFFDDE1FF),
    secondaryContainer = Color(0xFF2F3550),
    onSecondaryContainer = Color(0xFFDDE1FF),
    background = Color(0xFF0F1117),
    onBackground = Color(0xFFE3E2E9),
    surface = Color(0xFF0F1117),
    onSurface = Color(0xFFE3E2E9),
    error = Color(0xFFFFB4AB)
)

// Material 3: цвета Material You (динамические) на Android 12+, иначе запасная тёмная схема
@Composable
fun NightTheme(content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val scheme = if (Build.VERSION.SDK_INT >= 31) dynamicDarkColorScheme(ctx) else NightColors
    MaterialTheme(colorScheme = scheme, content = content)
}

/** Маленький таймер в правом верхнем углу: сколько осталось от "Ещё 10 минут". */
@Composable
fun BannerUi(ui: UiState) {
    NightTheme {
        val left = ui.extraLeft.coerceAtLeast(0)
        val urgent = left <= 60
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = if (urgent) MaterialTheme.colorScheme.errorContainer
            else MaterialTheme.colorScheme.primaryContainer,
            shadowElevation = 6.dp
        ) {
            Column(
                Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                horizontalAlignment = Alignment.End
            ) {
                Text("до блокировки", style = MaterialTheme.typography.labelSmall)
                Text(
                    "%02d:%02d".format(left / 60, left % 60),
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun LockUi(
    ui: UiState,
    onDigit: (Char) -> Unit,
    onBack: () -> Unit,
    onExtra: () -> Unit,
    onWifi: () -> Unit,
    onBluetooth: () -> Unit
) {
    NightTheme {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            val lockSec = Config.LOCK_MIN * 60
            val unlockSec = Config.UNLOCK_MIN * 60
            val left = (unlockSec - ui.sec).coerceAtLeast(0)
            val pct = ((ui.sec - lockSec) * 100 / (unlockSec - lockSec)).coerceIn(0, 100)
            val date = remember(ui.sec / 60) {
                val loc = Locale.getDefault()
                LocalDate.now()
                    .format(DateTimeFormatter.ofPattern("EEEE, d MMMM", loc))
                    .replaceFirstChar { it.uppercase() }
            }
            val battery = if (ui.battery >= 0)
                "Заряд ${ui.battery}%" + if (ui.charging) " · заряжается" else ""
            else ""

            Column(
                Modifier.fillMaxSize().padding(start = 24.dp, end = 24.dp, top = 56.dp, bottom = 32.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    "%02d:%02d".format(ui.sec / 3600, ui.sec % 3600 / 60),
                    style = MaterialTheme.typography.displayLarge
                )
                Text(date, style = MaterialTheme.typography.titleLarge)
                if (battery.isNotEmpty()) {
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = MaterialTheme.colorScheme.secondaryContainer,
                        modifier = Modifier.padding(top = 10.dp)
                    ) {
                        Text(
                            battery,
                            style = MaterialTheme.typography.labelLarge,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                        )
                    }
                }
                Spacer(Modifier.height(20.dp))
                Text(
                    "Пора спать. Разблокировка в ${Config.hm(Config.UNLOCK_MIN)}",
                    style = MaterialTheme.typography.titleMedium,
                    textAlign = TextAlign.Center
                )
                Text(
                    "Осталось %d ч %02d мин".format(left / 3600, left % 3600 / 60),
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(Modifier.height(12.dp))
                LinearProgressIndicator(
                    progress = { pct / 100f },
                    modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape)
                )
                Text(
                    "Ночь прошла на $pct%",
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(top = 6.dp)
                )
                if (ui.extraAvailable) {
                    Spacer(Modifier.height(16.dp))
                    OutlinedButton(onClick = onExtra) { Text("Ещё ${Config.EXTRA_MIN} минут") }
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    RadioToggle("Wi-Fi", ui.wifiOn, onWifi)
                    RadioToggle("Bluetooth", ui.btOn, onBluetooth)
                }
                Spacer(Modifier.weight(1f))
                Dots(ui.entered.length, Config.PASS_LEN, ui.error)
                Text(
                    if (ui.error) "Неверный пароль" else " ",
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(vertical = 8.dp)
                )
                listOf("123", "456", "789").forEach { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        row.forEach { ch -> Key(ch.toString(), Modifier.weight(1f)) { onDigit(ch) } }
                    }
                    Spacer(Modifier.height(12.dp))
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Spacer(Modifier.weight(1f))
                    Key("0", Modifier.weight(1f)) { onDigit('0') }
                    Key("⌫", Modifier.weight(1f)) { onBack() }
                }
            }
        }
    }
}

@Composable
private fun RadioToggle(name: String, on: Boolean, onClick: () -> Unit) {
    val label = "$name: " + if (on) "вкл" else "выкл"
    if (on) {
        FilledTonalButton(onClick = onClick) { Text(label) }
    } else {
        OutlinedButton(onClick = onClick) { Text(label) }
    }
}

@Composable
private fun Key(label: String, modifier: Modifier, onClick: () -> Unit) {
    FilledTonalButton(
        onClick = onClick,
        modifier = modifier.height(68.dp),
        shape = RoundedCornerShape(24.dp)
    ) {
        Text(label, style = MaterialTheme.typography.headlineSmall)
    }
}

@Composable
private fun Dots(count: Int, total: Int, error: Boolean) {
    val color = if (error) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        repeat(total) { i ->
            Box(
                Modifier
                    .size(14.dp)
                    .clip(CircleShape)
                    .background(if (i < count) color else Color.Transparent)
                    .border(2.dp, color, CircleShape)
            )
        }
    }
}
