package com.sleeplock.app

import android.accessibilityservice.AccessibilityService
import android.content.ComponentName
import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent

/** Общее состояние: LockService говорит, что экран блокировки сейчас на экране. */
object LockState {
    @Volatile var onChange: (() -> Unit)? = null

    @Volatile var locked = false
        set(value) {
            if (field != value) {
                field = value
                onChange?.invoke()
            }
        }

    fun panelBlockEnabled(c: Context): Boolean {
        val want = ComponentName(c, PanelBlockService::class.java)
        val s = Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?: return false
        return s.split(':').any { ComponentName.unflattenFromString(it) == want }
    }
}

/**
 * Пока экран блокировки включён, не даёт открыть шторку и быстрые настройки
 * (там кнопка активных приложений с "Остановить"):
 *  1) невидимая полоса поверх строки состояния съедает свайп вниз;
 *  2) если шторка всё же открылась — тут же закрываем её.
 * Ничего не читает с экрана и не нажимает за тебя.
 */
class PanelBlockService : AccessibilityService() {
    private var strip: View? = null
    private var lastClose = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        LockState.onChange = { sync() }
        sync()
    }

    private fun sync() {
        if (LockState.locked) addStrip() else removeStrip()
    }

    private fun addStrip() {
        if (strip != null) return
        try {
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            val d = resources.displayMetrics.density
            val id = resources.getIdentifier("status_bar_height", "dimen", "android")
            val bar = if (id > 0) resources.getDimensionPixelSize(id) else (32 * d).toInt()
            val v = View(this)
            v.setOnTouchListener { _, _ -> true }
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                bar + (10 * d).toInt(),
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP
            if (Build.VERSION.SDK_INT >= 28) {
                lp.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
            wm.addView(v, lp)
            strip = v
        } catch (_: Exception) {
        }
    }

    private fun removeStrip() {
        strip?.let {
            try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } catch (_: Exception) {}
        }
        strip = null
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || !LockState.locked) return
        if (event.packageName?.toString() != "com.android.systemui") return
        if (Watch.deviceLocked(this)) return
        val now = SystemClock.elapsedRealtime()
        if (now - lastClose < 300) return
        lastClose = now
        if (Build.VERSION.SDK_INT >= 31) {
            performGlobalAction(GLOBAL_ACTION_DISMISS_NOTIFICATION_SHADE)
        } else {
            performGlobalAction(GLOBAL_ACTION_HOME)
        }
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        LockState.onChange = null
        removeStrip()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        LockState.onChange = null
        removeStrip()
        super.onDestroy()
    }
}
