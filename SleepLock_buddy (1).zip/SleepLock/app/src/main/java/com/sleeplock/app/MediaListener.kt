package com.sleeplock.app

import android.content.Context
import android.service.notification.NotificationListenerService
import androidx.core.app.NotificationManagerCompat

/**
 * Пустая служба, нужна только чтобы система дала доступ к активному плееру
 * (название трека, позиция, перемотка). Уведомления она не читает.
 */
class MediaListener : NotificationListenerService()

object MediaAccess {
    fun enabled(c: Context): Boolean =
        NotificationManagerCompat.getEnabledListenerPackages(c).contains(c.packageName)
}
