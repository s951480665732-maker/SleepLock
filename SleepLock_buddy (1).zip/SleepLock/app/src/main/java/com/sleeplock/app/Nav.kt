package com.sleeplock.app

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

private val NAV_LABELS = listOf("Блокировка", "Кликер", "Музыка")

/** Нижняя панель-«таблетка»: выбранный пункт — с подписью и цветной плашкой, остальные — только значок. */
@Composable
fun NavPill(tab: Int, onTab: (Int) -> Unit, modifier: Modifier = Modifier) {
    Surface(
        shape = RoundedCornerShape(50),
        color = MaterialTheme.colorScheme.surfaceContainer,
        modifier = modifier.fillMaxWidth().height(64.dp)
    ) {
        Row(
            Modifier.padding(6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            NAV_LABELS.forEachIndexed { i, label ->
                val sel = i == tab
                val w by animateFloatAsState(if (sel) 2.2f else 1f, label = "navw")
                val tint = if (sel) MaterialTheme.colorScheme.onPrimaryContainer
                else MaterialTheme.colorScheme.onSurfaceVariant
                Box(
                    Modifier
                        .weight(w)
                        .fillMaxHeight()
                        .clip(RoundedCornerShape(50))
                        .background(if (sel) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
                        .clickable { onTab(i) },
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        NavIcon(i, tint)
                        if (sel) {
                            Text(
                                label,
                                color = tint,
                                style = MaterialTheme.typography.labelLarge,
                                maxLines = 1
                            )
                        }
                    }
                }
            }
        }
    }
}

// Значки рисуем сами, чтобы не тянуть большую библиотеку иконок
@Composable
private fun NavIcon(kind: Int, tint: Color) {
    Canvas(Modifier.size(24.dp)) {
        val w = size.width
        val h = size.height
        val sw = 2.2.dp.toPx()
        when (kind) {
            0 -> { // замок
                drawArc(
                    tint, startAngle = 180f, sweepAngle = 180f, useCenter = false,
                    topLeft = Offset(w * 0.28f, h * 0.08f), size = Size(w * 0.44f, h * 0.5f),
                    style = Stroke(sw, cap = StrokeCap.Round)
                )
                drawRoundRect(
                    tint, topLeft = Offset(w * 0.16f, h * 0.42f), size = Size(w * 0.68f, h * 0.5f),
                    cornerRadius = CornerRadius(w * 0.12f)
                )
            }
            1 -> { // мишень (кликер)
                drawCircle(tint, radius = w * 0.38f, style = Stroke(sw))
                drawCircle(tint, radius = w * 0.13f)
            }
            else -> { // нота
                drawCircle(tint, radius = w * 0.18f, center = Offset(w * 0.34f, h * 0.78f))
                drawLine(tint, Offset(w * 0.5f, h * 0.78f), Offset(w * 0.5f, h * 0.14f), strokeWidth = sw, cap = StrokeCap.Round)
                drawLine(tint, Offset(w * 0.5f, h * 0.14f), Offset(w * 0.86f, h * 0.3f), strokeWidth = sw, cap = StrokeCap.Round)
            }
        }
    }
}
