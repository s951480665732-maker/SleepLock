package com.sleeplock.app

import android.view.KeyEvent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

@Composable
fun MusicTab(
    ui: UiState,
    onKey: (Int) -> Unit,
    onSound: (Boolean) -> Unit,
    onVolume: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("🎵 Музыка", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(8.dp))
        Text(
            "Управляет плеером, который играл до блокировки (SoundCloud, Spotify и т. д.)",
            style = MaterialTheme.typography.bodyMedium,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(24.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Звук музыки", style = MaterialTheme.typography.titleMedium)
                Text(
                    if (ui.musicOn) "Включён до разблокировки" else "Выключен: музыка и видео немые",
                    style = MaterialTheme.typography.bodySmall
                )
            }
            Switch(checked = ui.musicOn, onCheckedChange = onSound)
        }
        Spacer(Modifier.height(24.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            MusicKey("⏮", Modifier.weight(1f)) { onKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS) }
            MusicKey("⏯", Modifier.weight(1f)) { onKey(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE) }
            MusicKey("⏭", Modifier.weight(1f)) { onKey(KeyEvent.KEYCODE_MEDIA_NEXT) }
        }
        Spacer(Modifier.height(24.dp))
        Text("Громкость", style = MaterialTheme.typography.titleSmall)
        if (ui.volMax > 0) {
            Slider(
                value = ui.vol.toFloat(),
                onValueChange = { onVolume(it.roundToInt()) },
                valueRange = 0f..ui.volMax.toFloat(),
                steps = (ui.volMax - 1).coerceAtLeast(0),
                enabled = ui.musicOn
            )
            Text("${ui.vol} / ${ui.volMax}", style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun MusicKey(label: String, modifier: Modifier, onClick: () -> Unit) {
    FilledTonalButton(
        onClick = onClick,
        modifier = modifier.height(72.dp),
        shape = RoundedCornerShape(24.dp)
    ) {
        Text(label, style = MaterialTheme.typography.headlineMedium)
    }
}
