package com.sleeplock.app

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.roundToInt
import kotlin.math.sin

private val Hues = listOf(0, 60, 120, 180, 240, 300, 360).map { Color.hsv(it.toFloat(), 1f, 1f) }
private const val SQRT2 = 1.4142135f

/** Кольцо оттенков + ромб насыщенности/яркости + RGB-ползунки (как на скриншоте). */
@Composable
fun ColorPicker(initial: Color, onColor: (Color) -> Unit, modifier: Modifier = Modifier) {
    val start = remember { FloatArray(3).also { android.graphics.Color.colorToHSV(initial.toArgb(), it) } }
    var h by remember { mutableFloatStateOf(start[0]) }
    var s by remember { mutableFloatStateOf(start[1]) }
    var v by remember { mutableFloatStateOf(start[2]) }
    val cb by rememberUpdatedState(onColor)

    fun emit() = cb(Color.hsv(h, s, v))
    fun setRgb(r: Int, g: Int, b: Int) {
        val a = FloatArray(3)
        android.graphics.Color.RGBToHSV(r, g, b, a)
        if (a[1] > 0f && a[2] > 0f) h = a[0]
        s = a[1]
        v = a[2]
        emit()
    }

    val cur = Color.hsv(h, s, v)
    val r8 = (cur.red * 255f).roundToInt()
    val g8 = (cur.green * 255f).roundToInt()
    val b8 = (cur.blue * 255f).roundToInt()

    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Canvas(
            Modifier
                .size(260.dp)
                .pointerInput(Unit) {
                    awaitEachGesture {
                        val down = awaitFirstDown()
                        val c = Offset(size.width / 2f, size.height / 2f)
                        val rOut = size.width / 2f
                        val rIn = rOut - rOut * 0.16f - rOut * 0.03f
                        val side = rIn * 0.95f * SQRT2
                        val d0 = down.position - c
                        val onRing = hypot(d0.x, d0.y) > rIn

                        fun upd(p: Offset) {
                            val d = p - c
                            if (onRing) {
                                h = ((Math.toDegrees(atan2(d.y.toDouble(), d.x.toDouble())) + 360.0) % 360.0).toFloat()
                            } else {
                                val a = (PI / 4).toFloat()
                                val lx = d.x * cos(a) + d.y * sin(a)
                                val ly = -d.x * sin(a) + d.y * cos(a)
                                s = ((lx + side / 2f) / side).coerceIn(0f, 1f)
                                v = (1f - (ly + side / 2f) / side).coerceIn(0f, 1f)
                            }
                            emit()
                        }

                        upd(down.position)
                        down.consume()
                        drag(down.id) { ch ->
                            upd(ch.position)
                            ch.consume()
                        }
                    }
                }
        ) {
            val rOut = size.width / 2f
            val c = center
            val t = rOut * 0.16f
            val rIn = rOut - t - rOut * 0.03f
            val side = rIn * 0.95f * SQRT2
            val hueColor = Color.hsv(h, 1f, 1f)

            // Кольцо оттенков
            drawCircle(Brush.sweepGradient(Hues, c), radius = rOut - t / 2f, center = c, style = Stroke(t))

            // Ромб: квадрат (слева направо — насыщенность, сверху вниз — к чёрному), повёрнутый на 45°
            rotate(45f, c) {
                translate(c.x - side / 2f, c.y - side / 2f) {
                    drawRect(
                        Brush.horizontalGradient(listOf(Color.White, hueColor), startX = 0f, endX = side),
                        size = Size(side, side)
                    )
                    drawRect(
                        Brush.verticalGradient(listOf(Color.Transparent, Color.Black), startY = 0f, endY = side),
                        size = Size(side, side)
                    )
                }
            }

            // Ползунок оттенка на кольце
            val ha = Math.toRadians(h.toDouble())
            val hp = Offset(
                c.x + (rOut - t / 2f) * cos(ha).toFloat(),
                c.y + (rOut - t / 2f) * sin(ha).toFloat()
            )
            drawCircle(hueColor, t * 0.5f, hp)
            drawCircle(Color(0xFFD9DCE8), t * 0.5f, hp, style = Stroke(3.dp.toPx()))

            // Ползунок в ромбе
            val a = (PI / 4).toFloat()
            val lx = (s - 0.5f) * side
            val ly = (0.5f - v) * side
            val sp = Offset(c.x + lx * cos(a) - ly * sin(a), c.y + lx * sin(a) + ly * cos(a))
            drawCircle(cur, 8.dp.toPx(), sp)
            drawCircle(Color(0xFFD9DCE8), 9.dp.toPx(), sp, style = Stroke(3.dp.toPx()))
        }

        Text(
            "#%06X".format(cur.toArgb() and 0xFFFFFF),
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.align(Alignment.Start)
        )
        Spacer(Modifier.height(4.dp))
        RgbRow("R", r8, Color(0xFFFF4D4D)) { setRgb(it, g8, b8) }
        RgbRow("G", g8, Color(0xFF3DDC6B)) { setRgb(r8, it, b8) }
        RgbRow("B", b8, Color(0xFF4D7DFF)) { setRgb(r8, g8, it) }
    }
}

@Composable
private fun RgbRow(label: String, value: Int, tint: Color, onChange: (Int) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.width(20.dp))
        Slider(
            value = value.toFloat(),
            onValueChange = { onChange(it.roundToInt()) },
            valueRange = 0f..255f,
            colors = SliderDefaults.colors(thumbColor = tint, activeTrackColor = tint),
            modifier = Modifier.weight(1f)
        )
        Text("$value", modifier = Modifier.width(36.dp))
    }
}
