package com.sleeplock.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.LargeTopAppBar
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import java.time.LocalTime
import androidx.compose.foundation.layout.size
import androidx.compose.material3.OutlinedButton
import androidx.compose.runtime.key
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb

class MainActivity : ComponentActivity() {
    private var resumes by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        Look.load(this)
        setContent { AppTheme { Home() } }
    }

    override fun onResume() {
        super.onResume()
        LockPolicy.ensurePassword(this)   // пароль на ближайшую ночь + zip
        resumes++
        Watch.start(this, LockService::class.java)
        Watch.start(this, GuardService::class.java)
    }

    private fun requestOverlay() {
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    private fun requestPanelBlock() {
        try {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        } catch (_: Exception) {
            openAppSettings()
        }
    }

    // Как на видео: "Без ограничений" для фоновой работы
    private fun requestBattery() {
        try {
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
            )
        } catch (_: Exception) {
            openAppSettings()
        }
    }

    private fun openAppSettings() {
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", packageName, null)))
    }

    private fun shareZip() {
        val uri = LockPolicy.zipUri(this)
        if (uri == null) {
            Toast.makeText(this, "ZIP ещё не создан, попробуй через секунду", Toast.LENGTH_SHORT).show()
            return
        }
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "application/zip"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(send, "Переслать ZIP с паролем"))
    }

    @Composable
    private fun AppTheme(content: @Composable () -> Unit) {
        val dark = isSystemInDarkTheme()
        val ctx = LocalContext.current
        val scheme = when {
            Build.VERSION.SDK_INT >= 31 ->
                if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
            dark -> darkColorScheme()
            else -> lightColorScheme()
        }
        MaterialTheme(colorScheme = scheme, content = content)
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    private fun Home() {
        val ctx = LocalContext.current
        val sec by produceState(LocalTime.now().toSecondOfDay()) {
            while (true) {
                value = LocalTime.now().toSecondOfDay()
                delay(1000)
            }
        }
        val r = resumes
        val overlayOk = remember(r) { Settings.canDrawOverlays(ctx) }
        val notifOk = remember(r) {
            Build.VERSION.SDK_INT < 33 ||
                ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        }
        val batteryOk = remember(r) {
            ctx.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(ctx.packageName)
        }
        val panelOk = remember(r) { LockState.panelBlockEnabled(ctx) }
        val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
            resumes++
        }
        val night = remember(sec / 60) { LockPolicy.nightKey() }

        fun requestNext() {
            when {
                !overlayOk -> requestOverlay()
                !notifOk -> if (Build.VERSION.SDK_INT >= 33) {
                    notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
                !batteryOk -> requestBattery()
                !panelOk -> requestPanelBlock()
            }
        }

        // Само просит разрешения по очереди, пока не дашь все
        val allOk = overlayOk && notifOk && batteryOk && panelOk
        var askDismissed by rememberSaveable { mutableStateOf(false) }
        if (!allOk && !askDismissed) {
            AlertDialog(
                onDismissRequest = { askDismissed = true },
                title = { Text("Нужны разрешения") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Без них блокировка не сработает.")
                        Text((if (overlayOk) "✓" else "•") + "  Поверх всех окон — таймер и экран блокировки")
                        Text((if (notifOk) "✓" else "•") + "  Уведомления — чтобы приложение жило в фоне")
                        Text((if (batteryOk) "✓" else "•") + "  Без ограничений батареи — чтобы система не убила его ночью")
                        Text((if (panelOk) "✓" else "•") + "  Спец. возможности — чтобы ночью нельзя было открыть шторку")
                    }
                },
                confirmButton = { TextButton(onClick = { requestNext() }) { Text("Разрешить") } },
                dismissButton = { TextButton(onClick = { askDismissed = true }) { Text("Позже") } }
            )
        }

        val status = when (LockPolicy.phase(ctx, sec)) {
            Phase.IDLE -> "Следующая блокировка в ${Config.hm(Config.LOCK_MIN)}"
            Phase.EXTRA -> "Дополнительное время, потом блокировка"
            Phase.LOCKED -> "Заблокировано до ${Config.hm(Config.UNLOCK_MIN)}"
        }

        val scroll = TopAppBarDefaults.exitUntilCollapsedScrollBehavior()
        Scaffold(
            modifier = Modifier.nestedScroll(scroll.nestedScrollConnection),
            topBar = {
                LargeTopAppBar(
                    title = { Text("Sleep Lock") },
                    scrollBehavior = scroll
                )
            }
        ) { pad ->
            Column(
                Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {

                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(24.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            "%02d:%02d:%02d".format(sec / 3600, sec % 3600 / 60, sec % 60),
                            style = MaterialTheme.typography.displayLarge
                        )
                        Text(status, style = MaterialTheme.typography.titleMedium)
                    }
                }

                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Пароль на ночь $night", style = MaterialTheme.typography.titleMedium)
                        Text(
                            "Пароль новый каждый день и случайный. Здесь он не показывается — " +
                                "он лежит в ZIP (внутри password.txt). Перешли ZIP тому, кто будет " +
                                "его хранить, и не открывай."
                        )
                        Button(onClick = { shareZip() }, modifier = Modifier.fillMaxWidth()) {
                            Text("Переслать ZIP")
                        }
                    }
                }

                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Расписание", style = MaterialTheme.typography.titleMedium)
                        Text("${Config.hm(Config.LOCK_MIN)} — звук выключается, выход из приложения, блокировка")
                        Text("Кнопка «Ещё ${Config.EXTRA_MIN} ${Config.minutesWord(Config.EXTRA_MIN)}» — отсрочка, в углу таймер сколько осталось")
                        Text("На блокировке можно открыть Wi-Fi / Bluetooth на ${Config.PANEL_SEC} секунд")
                        Text("${Config.hm(Config.UNLOCK_MIN)} — автоматическая разблокировка")
                    }
                }

                PermissionCard("Поверх всех окон", overlayOk) { requestOverlay() }
                PermissionCard("Уведомления", notifOk) {
                    if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
                PermissionCard(
                    "Без ограничений батареи", batteryOk,
                    hint = "Если окно не появилось: Настройки приложения → Батарея → Без ограничений",
                    onHint = { openAppSettings() }
                ) { requestBattery() }
                PermissionCard(
                    "Шторка закрыта ночью", panelOk,
                    hint = "Включи «Sleep Lock: закрывать шторку» в спец. возможностях. Если пункт серый: " +
                        "Настройки приложения → ⋮ → Разрешить ограниченные настройки",
                    onHint = { openAppSettings() }
                ) { requestPanelBlock() }

                EyesCard()
            }
        }
    }

    @Composable
    private fun EyesCard() {
        val ctx = LocalContext.current
        var pickerKey by remember { mutableIntStateOf(0) }
        ElevatedCard(Modifier.fillMaxWidth()) {
            Column(
                Modifier.padding(16.dp).fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    "Глаза персонажа",
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.align(Alignment.Start)
                )
                BuddyFace(Modifier.size(96.dp), Color(Look.eye), Offset(0.5f, 0.2f), 1f)
                key(pickerKey) {
                    ColorPicker(Color(Look.eye), onColor = {
                        Look.eye = it.toArgb()
                        Look.save(ctx)
                    })
                }
                OutlinedButton(onClick = {
                    Look.eye = Look.DEFAULT_EYE
                    Look.save(ctx)
                    pickerKey++
                }) { Text("Белые глаза") }
            }
        }
    }

    @Composable
    private fun PermissionCard(
        title: String,
        ok: Boolean,
        hint: String? = null,
        onHint: (() -> Unit)? = null,
        onFix: () -> Unit
    ) {
        ElevatedCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(title, style = MaterialTheme.typography.titleMedium)
                        Text(
                            if (ok) "Включено" else "Нужно разрешить",
                            color = if (ok) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                        )
                    }
                    if (!ok) FilledTonalButton(onClick = onFix) { Text("Разрешить") }
                }
                if (!ok && hint != null) {
                    Text(hint, style = MaterialTheme.typography.bodySmall)
                    if (onHint != null) {
                        TextButton(onClick = onHint) { Text("Открыть настройки приложения") }
                    }
                }
            }
        }
    }
}
