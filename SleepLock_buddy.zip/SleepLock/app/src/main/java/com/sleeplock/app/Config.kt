package com.sleeplock.app

object Config {
    // Всё в минутах от полуночи — можно менять для теста
    const val LOCK_MIN = 30      // 00:30 (12:30 AM) — блокировка
    const val UNLOCK_MIN = 330   // 05:30 — авто-разблокировка

    const val EXTRA_MIN = 3          // кнопка "Ещё 3 минуты"
    const val EXTRA_PER_NIGHT = 1    // сколько раз за ночь можно нажать

    const val PANEL_SEC = 20         // на сколько секунд открывается Wi-Fi / Bluetooth на блокировке

    const val TEST_MIN = 10          // тест блокировки сам заканчивается через столько минут

    const val PASS_LEN = 8       // длина случайного пароля (цифры)

    // "1 минуту", "3 минуты", "10 минут"
    fun minutesWord(n: Int): String = when {
        n % 100 in 11..14 -> "минут"
        n % 10 == 1 -> "минуту"
        n % 10 in 2..4 -> "минуты"
        else -> "минут"
    }

    fun hm(min: Int): String = "%02d:%02d".format(min / 60, min % 60)
}
