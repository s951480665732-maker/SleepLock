package com.sleeplock.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue

/** Внешний вид персонажа: цвет глаз (меняется палитрой в приложении). */
object Look {
    const val DEFAULT_EYE = 0xFFFFFFFF.toInt()

    var eye by mutableIntStateOf(DEFAULT_EYE)

    private fun prefs(c: Context) = c.getSharedPreferences("look", Context.MODE_PRIVATE)

    fun load(c: Context) {
        eye = prefs(c).getInt("eye", DEFAULT_EYE)
    }

    fun save(c: Context) {
        prefs(c).edit().putInt("eye", eye).apply()
    }
}
