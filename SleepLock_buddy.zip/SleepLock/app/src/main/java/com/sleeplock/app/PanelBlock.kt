package com.sleeplock.app

import android.accessibilityservice.AccessibilityService
import android.content.ComponentName
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PixelFormat
import android.os.Build
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowInsets
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue

/** Общее состояние: LockService говорит, что экран блокировки сейчас на экране. */
object LockState {
    @Volatile var onChange: (() -> Unit)? = null

    @Volatile var locked = false
        set(value) {
            if (field != value) {
                field = value
                onChange?.invoke()
            }
        }

    // Цвет фона экрана блокировки (его сообщает сам экран) — полосы сверху/снизу красятся им же
    @Volatile var bgColor: Int = 0xFF0F1117.toInt()

    // Высота закрытых полос в dp — экран блокировки отступает от них
    var statusTopDp by mutableIntStateOf(0)
    var navBottomDp by mutableIntStateOf(0)

    fun panelBlockEnabled(c: Context): Boolean {
        val want = ComponentName(c, PanelBlockService::class.java)
        val s = Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?: return false
        return s.split(':').any { ComponentName.unflattenFromString(it) == want }
    }
}

/** Полоса поверх системной панели: красится цветом экрана блокировки и съедает касания. */
private class BarView(c: Context, private val solidTop: Int?) : View(c) {
    private val paint = Paint()

    init {
        setOnTouchListener { _, _ -> true }
    }

    override fun onDraw(canvas: Canvas) {
        paint.color = LockState.bgColor
        val bottom = solidTop ?: height
        canvas.drawRect(0f, 0f, width.toFloat(), bottom.toFloat(), paint)
    }
}

/**
 * Пока экран блокировки включён, закрывает системные панели, чтобы блок был на весь экран:
 *  1) строка состояния и кнопки навигации перекрыты полосами цвета экрана блокировки —
 *     шторку не открыть, кнопки не нажать;
 *  2) если шторка всё же открылась — тут же закрываем её.
 * Ничего не читает с экрана и не нажимает за тебя.
 */
class PanelBlockService : AccessibilityService() {
    private var top: View? = null
    private var bottom: View? = null
    private var lastClose = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        LockState.onChange = { sync() }
        sync()
    }

    private fun sync() {
        if (LockState.locked) addBars() else removeBars()
    }

    private fun params(h: Int, g: Int): WindowManager.LayoutParams {
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            h,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = g
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        return lp
    }

    private fun addBars() {
        if (top != null) return
        try {
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            val d = resources.displayMetrics.density
            val id = resources.getIdentifier("status_bar_height", "dimen", "android")
            val bar = if (id > 0) resources.getDimensionPixelSize(id) else (32 * d).toInt()
            var nav = 0
            if (Build.VERSION.SDK_INT >= 30) {
                nav = wm.currentWindowMetrics.windowInsets
                    .getInsetsIgnoringVisibility(WindowInsets.Type.navigationBars()).bottom
            }

            // Сверху: закрашенная строка состояния + 10dp запаса, чтобы свайп вниз не проскочил
            val t = BarView(this, bar)
            wm.addView(t, params(bar + (10 * d).toInt(), Gravity.TOP))
            top = t
            LockState.statusTopDp = (bar / d).toInt()

            // Снизу: панель навигации
            if (nav > 0) {
                val b = BarView(this, null)
                wm.addView(b, params(nav, Gravity.BOTTOM))
                bottom = b
                LockState.navBottomDp = (nav / d).toInt()
            }

            // Цвет фона приходит от экрана блокировки чуть позже первого кадра — перерисуем
            for (delay in longArrayOf(300, 1200)) {
                t.postDelayed({ t.invalidate(); bottom?.invalidate() }, delay)
            }
        } catch (_: Exception) {
        }
    }

    private fun removeBars() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        for (v in listOf(top, bottom)) {
            if (v != null) try { wm.removeView(v) } catch (_: Exception) {}
        }
        top = null
        bottom = null
        LockState.statusTopDp = 0
        LockState.navBottomDp = 0
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || !LockState.locked) return
        if (event.packageName?.toString() != "com.android.systemui") return
        if (Watch.deviceLocked(this)) return
        val now = SystemClock.elapsedRealtime()
        if (now - lastClose < 300) return
        lastClose = now
        if (Build.VERSION.SDK_INT >= 31) {
            performGlobalAction(GLOBAL_ACTION_DISMISS_NOTIFICATION_SHADE)
        } else {
            performGlobalAction(GLOBAL_ACTION_HOME)
        }
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        LockState.onChange = null
        removeBars()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        LockState.onChange = null
        removeBars()
        super.onDestroy()
    }
}
