package com.sleeplock.app

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.floor
import kotlin.math.pow

object Clicker {
    class Up(val name: String, val desc: String, val baseCost: Double, val growth: Double)

    val ups = listOf(
        Up("Сильный палец", "+1 за клик", 15.0, 1.35),
        Up("Автокликер", "+1 в секунду", 60.0, 1.4),
        Up("Звёздная ферма", "+8 в секунду", 500.0, 1.5),
        Up("Лунный множитель", "+25% ко всему", 2000.0, 2.2)
    )

    fun cost(i: Int, level: Int): Long = (ups[i].baseCost * ups[i].growth.pow(level)).toLong()

    private fun mult(l: List<Int>) = 1.0 + 0.25 * l[3]
    fun perClick(l: List<Int>) = (1 + l[0]) * mult(l)
    fun perSec(l: List<Int>) = (l[1] + 8 * l[2]) * mult(l)

    private fun prefs(c: Context) = c.getSharedPreferences("clicker", Context.MODE_PRIVATE)

    fun load(c: Context, ui: UiState) {
        val p = prefs(c)
        ui.score = p.getString("score", null)?.toDoubleOrNull() ?: 0.0
        for (i in ups.indices) ui.levels[i] = p.getInt("lvl$i", 0)
    }

    fun save(c: Context, ui: UiState) {
        val e = prefs(c).edit().putString("score", ui.score.toString())
        for (i in ups.indices) e.putInt("lvl$i", ui.levels[i])
        e.apply()
    }
}

private fun fmtInt(v: Double) = "%,d".format(v.toLong())
private fun fmtNum(v: Double) = if (v == floor(v)) "%,d".format(v.toLong()) else "%.2f".format(v)

@Composable
fun ClickerTab(ui: UiState, onTap: () -> Unit, onBuy: (Int) -> Unit, modifier: Modifier = Modifier) {
    Column(
        modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("🌙 ${fmtInt(ui.score)}", style = MaterialTheme.typography.displaySmall)
        Text(
            "за клик: ${fmtNum(Clicker.perClick(ui.levels))} · в секунду: ${fmtNum(Clicker.perSec(ui.levels))}",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(Modifier.height(14.dp))
        Box(
            Modifier
                .size(150.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primaryContainer)
                .clickable { onTap() },
            contentAlignment = Alignment.Center
        ) {
            Text("🌙", fontSize = 64.sp)
        }
        Spacer(Modifier.height(14.dp))
        Column(
            Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Clicker.ups.forEachIndexed { i, up ->
                val lvl = ui.levels[i]
                val cost = Clicker.cost(i, lvl)
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("${up.name} · ур. $lvl", style = MaterialTheme.typography.titleSmall)
                            Text(up.desc, style = MaterialTheme.typography.bodySmall)
                        }
                        FilledTonalButton(onClick = { onBuy(i) }, enabled = ui.score >= cost) {
                            Text("%,d 🌙".format(cost))
                        }
                    }
                }
            }
        }
    }
}
