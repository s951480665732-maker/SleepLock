package com.sleeplock.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Watch.start(context, LockService::class.java)
        Watch.start(context, GuardService::class.java)
    }
}
