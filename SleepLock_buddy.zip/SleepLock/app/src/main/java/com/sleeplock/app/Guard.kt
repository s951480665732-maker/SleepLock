package com.sleeplock.app

import android.app.ActivityManager
import android.app.KeyguardManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat

object Watch {
    /** Телефон заблокирован (экран блокировки) или экран выключен — в это время ничего не проверяем. */
    fun deviceLocked(c: Context): Boolean {
        val kg = c.getSystemService(KeyguardManager::class.java)
        val pm = c.getSystemService(PowerManager::class.java)
        return kg?.isKeyguardLocked == true || pm?.isInteractive == false
    }

    /** Работает ли сервис (свои сервисы приложения система показывает и из другого процесса). */
    @Suppress("DEPRECATION")
    fun isRunning(c: Context, cls: Class<*>): Boolean = try {
        c.getSystemService(ActivityManager::class.java)
            .getRunningServices(200)
            .any { it.service.className == cls.name }
    } catch (_: Exception) {
        true   // не смогли узнать — не трогаем, чтобы не плодить перезапуски
    }

    fun start(c: Context, cls: Class<*>) {
        try {
            ContextCompat.startForegroundService(c, Intent(c, cls))
        } catch (_: Exception) {
        }
    }

    /** Одно и то же уведомление (id = 1) у обоих сервисов — на экране оно одно. */
    fun foreground(s: Service) {
        val channel = "sleeplock"
        val nm = s.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(channel, "Режим сна", NotificationManager.IMPORTANCE_LOW)
        )
        val n: Notification = Notification.Builder(s, channel)
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setContentTitle("Режим сна включён")
            .setContentText("Блокировка в ${Config.hm(Config.LOCK_MIN)}, разблокировка в ${Config.hm(Config.UNLOCK_MIN)}")
            .setOngoing(true)
            .build()
        ServiceCompat.startForeground(s, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
    }
}

/**
 * Страж. Живёт в отдельном процессе (:guard), раз в секунду проверяет, что LockService работает,
 * и если его закрыли или убили — запускает заново. Пока телефон заблокирован — не проверяет,
 * при разблокировке проверяет сразу.
 */
class GuardService : Service() {
    private val handler = Handler(Looper.getMainLooper())

    private val loop = object : Runnable {
        override fun run() {
            try {
                check()
            } catch (_: Exception) {
            }
            handler.postDelayed(this, 1000)
        }
    }

    private val wake = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            handler.removeCallbacks(loop)
            handler.post(loop)
        }
    }

    private fun check() {
        if (Watch.deviceLocked(this)) return
        if (!Watch.isRunning(this, LockService::class.java)) {
            Watch.start(this, LockService::class.java)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Watch.foreground(this)
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_USER_PRESENT)
            addAction(Intent.ACTION_SCREEN_ON)
        }
        ContextCompat.registerReceiver(this, wake, f, ContextCompat.RECEIVER_NOT_EXPORTED)
        handler.post(loop)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onTaskRemoved(rootIntent: Intent?) {
        Watch.start(this, LockService::class.java)
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try { unregisterReceiver(wake) } catch (_: Exception) {}
        super.onDestroy()
    }
}
