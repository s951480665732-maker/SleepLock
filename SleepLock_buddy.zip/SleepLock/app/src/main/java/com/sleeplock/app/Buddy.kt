package com.sleeplock.app

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.random.Random

/** Сам персонаж: чёрный круг и два глаза (цвет глаз — из палитры). look — куда смотрят, от -1 до 1. */
@Composable
fun BuddyFace(modifier: Modifier, eyeColor: Color, look: Offset, blink: Float) {
    Canvas(modifier) {
        val r = size.minDimension / 2f
        val c = center
        drawCircle(Color.Black, r, c)
        drawCircle(Color(0x88B8C4FF), r - 1.dp.toPx(), c, style = Stroke(1.5.dp.toPx()))
        val bodyPath = Path().apply { addOval(Rect(Offset(c.x - r, c.y - r), Size(2f * r, 2f * r))) }
        clipPath(bodyPath) {
            val k = 0.10f
            fun eye(cx: Float, cy: Float, rx: Float, ry: Float) {
                val h = ry * blink.coerceIn(0.06f, 1f)
                drawOval(
                    eyeColor,
                    Offset(c.x + (cx + look.x * k) * r - rx * r, c.y + (cy + look.y * k) * r - h * r),
                    Size(2f * rx * r, 2f * h * r)
                )
            }
            // Размеры и места как на картинке: левый глаз поменьше, правый пошире
            eye(-0.30f, -0.51f, 0.22f, 0.20f)
            eye(0.40f, -0.52f, 0.24f, 0.19f)
        }
    }
}

/**
 * Окно-персонаж поверх всего: справа во время блокировки, слева — пока идёт "Ещё N минут"
 * (справа тогда таймер). Глаза следят за пальцем, моргает, дышит, при переходе идёт прыжками.
 */
@Composable
fun BuddyOverlay(ui: UiState) {
    val density = LocalDensity.current
    val view = LocalView.current
    val body = 56.dp
    val twoPi = (2 * PI).toFloat()

    // Положение: 1 = правый угол, 0 = левый. Переход — анимированный.
    val pos = remember { Animatable(ui.charPos) }
    LaunchedEffect(ui.charLeft) {
        pos.animateTo(if (ui.charLeft) 0f else 1f, tween(1500, easing = FastOutSlowInEasing)) {
            ui.charPos = value
        }
    }

    // Моргание
    val blink = remember { Animatable(1f) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(Random.nextLong(2200, 5200))
            blink.animateTo(0.08f, tween(70))
            blink.animateTo(1f, tween(120))
        }
    }

    // Один медленный цикл: дыхание и блуждающий взгляд
    val w by rememberInfiniteTransition(label = "idle").animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(14000, easing = LinearEasing)),
        label = "w"
    )

    var center by remember { mutableStateOf(Offset.Zero) }

    val p = pos.value
    val moving = 4f * p * (1f - p)                 // 0 у краёв, 1 посередине пути
    val gait = sin(p * PI.toFloat() * 7f)
    val hop = abs(gait) * 10f * moving             // dp: прыжки на ходу
    val tilt = gait * 9f * moving                  // наклон на ходу
    val bob = sin(w * twoPi * 6f) * 2.5f           // dp: дыхание

    val fresh = !ui.charLeft && ui.touchAt != 0L && System.currentTimeMillis() - ui.touchAt < 4000
    val look: Offset = when {
        moving > 0.02f -> Offset(if (ui.charLeft) -0.9f else 0.9f, 0.1f)             // смотрит по ходу
        fresh -> {                                                                   // следит за пальцем
            val dx = ui.touchX - center.x
            val dy = ui.touchY - center.y
            val dist = hypot(dx, dy).coerceAtLeast(1f)
            val k = min(dist / (160f * density.density), 1f)
            Offset(dx / dist * k, dy / dist * k)
        }
        ui.charLeft -> Offset(0.85f + cos(w * twoPi * 3f) * 0.1f, 0.2f)              // поглядывает на таймер
        else -> Offset(cos(w * twoPi) * 0.7f, sin(w * twoPi * 2f) * 0.4f)            // скучает, глазеет вокруг
    }

    BoxWithConstraints(Modifier.fillMaxWidth().height(body + 28.dp)) {
        val widthPx = constraints.maxWidth.toFloat()
        val bodyPx = with(density) { body.toPx() }
        val margin = with(density) { 12.dp.toPx() }
        val x = margin + (widthPx - bodyPx - 2f * margin) * p
        val y = with(density) { (14.dp + (bob - hop).dp).toPx() }

        BuddyFace(
            Modifier
                .offset { IntOffset(x.roundToInt(), y.roundToInt()) }
                .size(body)
                .graphicsLayer { rotationZ = tilt }
                .onGloballyPositioned { c ->
                    val r = c.positionInRoot()
                    val loc = IntArray(2)
                    view.getLocationOnScreen(loc)
                    center = Offset(loc[0] + r.x + c.size.width / 2f, loc[1] + r.y + c.size.height / 2f)
                },
            Color(Look.eye),
            look,
            blink.value
        )
    }
}
