package com.sleeplock.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.AlarmManager
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.bluetooth.BluetoothManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.widget.FrameLayout
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.ComposeView
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import java.time.LocalTime

// Нужен, чтобы Compose работал внутри окна, созданного сервисом
class OverlayOwner : LifecycleOwner, ViewModelStoreOwner, SavedStateRegistryOwner {
    private val registry = LifecycleRegistry(this)
    private val controller = SavedStateRegistryController.create(this)
    private val store = ViewModelStore()

    override val lifecycle: Lifecycle get() = registry
    override val viewModelStore: ViewModelStore get() = store
    override val savedStateRegistry: SavedStateRegistry get() = controller.savedStateRegistry

    init {
        controller.performAttach()
        controller.performRestore(null)
    }

    fun start() {
        registry.currentState = Lifecycle.State.RESUMED
    }

    fun stop() {
        registry.currentState = Lifecycle.State.DESTROYED
        store.clear()
    }
}

class LockService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private val ui = UiState()
    private val owner = OverlayOwner()
    private lateinit var wm: WindowManager
    private lateinit var audio: AudioManager
    private var lockView: View? = null
    private var bannerView: ComposeView? = null
    private var focusRequest: AudioFocusRequest? = null
    private var ensuredKey = ""
    private var panelUntil = 0L   // до этого момента блокировка временно снята (окно Wi-Fi/Bluetooth)

    private var healthTicks = 0
    private var buddyView: ComposeView? = null
    private var clickDirty = false
    private var clickTicks = 0

    private val tick = object : Runnable {
        override fun run() {
            healthCheck()   // раз в секунду: всё ли на месте (пока телефон заблокирован — пропускаем)
            try {
                onTick()
            } catch (_: Exception) {
            }
            clickerTick()
            readVolume()
            handler.postDelayed(this, 1000)
        }
    }

    // Экран включили / разблокировали — проверяем сразу, не ждём секунду
    private val wake = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            handler.removeCallbacks(tick)
            handler.post(tick)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        audio = getSystemService(AUDIO_SERVICE) as AudioManager
        owner.start()
        Clicker.load(this, ui)
        Look.load(this)
        startAsForeground()
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_USER_PRESENT)
            addAction(Intent.ACTION_SCREEN_ON)
        }
        ContextCompat.registerReceiver(this, wake, f, ContextCompat.RECEIVER_NOT_EXPORTED)
        Watch.start(this, GuardService::class.java)
        handler.post(tick)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try { unregisterReceiver(wake) } catch (_: Exception) {}
        removeCharacter()
        removeLock()
        removeBanner()
        owner.stop()
        scheduleRestart()   // если сервис остановили (например, из диспетчера задач) — поднимаем снова
        super.onDestroy()
    }

    // Смахнули приложение из последних — сервис должен жить дальше
    override fun onTaskRemoved(rootIntent: Intent?) {
        scheduleRestart()
        super.onTaskRemoved(rootIntent)
    }

    private fun scheduleRestart() {
        try {
            val pi = PendingIntent.getBroadcast(
                this, 7, Intent(this, BootReceiver::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            getSystemService(AlarmManager::class.java).setAndAllowWhileIdle(
                AlarmManager.ELAPSED_REALTIME_WAKEUP,
                SystemClock.elapsedRealtime() + 1500,
                pi
            )
        } catch (_: Exception) {
        }
    }

    private fun startAsForeground() = Watch.foreground(this)

    // Проверка "всё ли хорошо" — раз в секунду. Пока телефон заблокирован, не проверяем (до разблокировки).
    private fun healthCheck() {
        if (Watch.deviceLocked(this)) return
        try {
            // 1. Страж (другой процесс) жив? Если закрыт — запускаем
            if (!Watch.isRunning(this, GuardService::class.java)) {
                Watch.start(this, GuardService::class.java)
            }

            // 2. Система могла убрать наши окна — тогда onTick() создаст их заново
            if (lockView?.isAttachedToWindow == false) detachLockView()
            if (bannerView?.isAttachedToWindow == false) removeBanner()
            if (buddyView?.isAttachedToWindow == false) removeCharacter()

            // 3. Раз в 30 секунд: уведомление на месте, пароль на ночь и zip в порядке
            if (++healthTicks % 30 == 0) {
                startAsForeground()
                LockPolicy.ensurePassword(this)
            }
        } catch (_: Exception) {
        }
    }

    // ---------- Музыка ----------
    private fun onMusicKey(code: Int) {
        try {
            val t = SystemClock.uptimeMillis()
            audio.dispatchMediaKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_DOWN, code, 0))
            audio.dispatchMediaKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_UP, code, 0))
        } catch (_: Exception) {
        }
    }

    private fun onSound(on: Boolean) {
        ui.musicOn = on
        if (on) {
            try {
                if (audio.isStreamMute(AudioManager.STREAM_MUSIC)) {
                    audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0)
                }
            } catch (_: Exception) {
            }
            LockPolicy.setMutedByUs(this, false)
            focusRequest?.let {
                try { audio.abandonAudioFocusRequest(it) } catch (_: Exception) {}
            }
            focusRequest = null
        } else {
            enforceMute()
            takeAudioFocus()
        }
        readVolume()
    }

    private fun onVolume(v: Int) {
        try {
            audio.setStreamVolume(AudioManager.STREAM_MUSIC, v, 0)
            ui.vol = v
        } catch (_: Exception) {
        }
    }

    private fun readVolume() {
        if (lockView == null) return
        try {
            ui.volMax = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            ui.vol = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
        } catch (_: Exception) {
        }
    }

    // ---------- Кликер ----------
    private fun onTap() {
        ui.score += Clicker.perClick(ui.levels)
        clickDirty = true
    }

    private fun onBuy(i: Int) {
        val cost = Clicker.cost(i, ui.levels[i])
        if (ui.score >= cost) {
            ui.score -= cost
            ui.levels[i] = ui.levels[i] + 1
            clickDirty = true
            saveClicker()
        }
    }

    // Раз в секунду, пока экран блокировки на экране, капает доход от автокликеров
    private fun clickerTick() {
        if (lockView != null) {
            val ps = Clicker.perSec(ui.levels)
            if (ps > 0) {
                ui.score += ps
                clickDirty = true
            }
        }
        if (clickDirty && ++clickTicks >= 10) saveClicker()
    }

    private fun saveClicker() {
        if (!clickDirty) return
        Clicker.save(this, ui)
        clickDirty = false
        clickTicks = 0
    }

    private fun onTick() {
        ui.sec = LocalTime.now().toSecondOfDay()

        // Случайный пароль на ближайшую ночь (лежит только в zip)
        val key = LockPolicy.nightKey()
        if (key != ensuredKey && LockPolicy.ensurePassword(this)) ensuredKey = key

        if (ui.battery < 0 || ui.sec % 10 == 0) readBattery()

        ui.extraLeft = LockPolicy.extraLeftSec(this)
        ui.extraAvailable = LockPolicy.extraAvailable(this)

        var phase = LockPolicy.phase(this, ui.sec)
        if (!Settings.canDrawOverlays(this)) phase = Phase.IDLE

        if (phase == Phase.LOCKED) {
            if (lockView == null && SystemClock.elapsedRealtime() >= panelUntil) {
                addLock()
                if (lockView != null) onLocked()   // заодно выкидывает из открытых настроек
            }
            if (lockView != null) enforceMute()
            readRadios()
        } else {
            removeLock()
        }
        if (phase == Phase.EXTRA) addBanner() else removeBanner()

        // Персонаж: справа пока идёт блокировка, слева пока идёт "Ещё N минут" (справа тогда таймер)
        ui.charLeft = phase != Phase.LOCKED
        if ((phase == Phase.LOCKED && lockView != null) || phase == Phase.EXTRA) addCharacter() else removeCharacter()
    }

    private fun addCharacter() {
        if (buddyView != null) return
        val v = composeView { BuddyOverlay(ui) }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = android.view.Gravity.TOP
        val d = resources.displayMetrics.density
        val sbId = resources.getIdentifier("status_bar_height", "dimen", "android")
        lp.y = if (sbId > 0) resources.getDimensionPixelSize(sbId) else (24 * d).toInt()
        try {
            wm.addView(v, lp)
            buddyView = v
        } catch (_: Exception) {
        }
    }

    private fun removeCharacter() {
        buddyView?.let {
            try { wm.removeView(it) } catch (_: Exception) {}
        }
        buddyView = null
    }

    private fun readRadios() {
        try {
            ui.wifiOn = (applicationContext.getSystemService(WIFI_SERVICE) as WifiManager).isWifiEnabled
        } catch (_: Exception) {
        }
        try {
            ui.btOn = getSystemService(BluetoothManager::class.java)?.adapter?.isEnabled == true
        } catch (_: Exception) {
        }
    }

    // Android не даёт приложениям включать Wi-Fi/Bluetooth напрямую, поэтому открываем
    // системное окно и на PANEL_SEC секунд прячем блокировку. Потом она возвращается.
    private fun openSystemRadio(intent: Intent) {
        try {
            startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            panelUntil = SystemClock.elapsedRealtime() + Config.PANEL_SEC * 1000L
            detachLockView()
        } catch (_: Exception) {
        }
    }

    private fun onWifi() {
        openSystemRadio(
            if (Build.VERSION.SDK_INT >= 29) Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)
            else Intent(Settings.ACTION_WIFI_SETTINGS)
        )
    }

    private fun onBluetooth() {
        openSystemRadio(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
    }

    private fun readBattery() {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        if (level >= 0 && scale > 0) ui.battery = level * 100 / scale
        val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        ui.charging = st == BatteryManager.BATTERY_STATUS_CHARGING ||
            st == BatteryManager.BATTERY_STATUS_FULL
    }

    // ---------- Момент блокировки: ставим на паузу, глушим звук, выходим из приложения ----------

    private fun onLocked() {
        pauseMedia()
        takeAudioFocus()
        enforceMute()
        // Уходим на домашний экран — из приложения, в котором был человек.
        // Запуск из фона разрешён, т.к. у нас есть "Поверх всех окон".
        handler.postDelayed({ goHome() }, 400)
    }

    private fun goHome() {
        try {
            startActivity(
                Intent(Intent.ACTION_MAIN)
                    .addCategory(Intent.CATEGORY_HOME)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (_: Exception) {
        }
    }

    private fun pauseMedia() {
        try {
            val t = SystemClock.uptimeMillis()
            audio.dispatchMediaKeyEvent(
                KeyEvent(t, t, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PAUSE, 0)
            )
            audio.dispatchMediaKeyEvent(
                KeyEvent(t, t, KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PAUSE, 0)
            )
        } catch (_: Exception) {
        }
    }

    private fun takeAudioFocus() {
        if (focusRequest != null) return
        try {
            val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setOnAudioFocusChangeListener { _ -> }
                .build()
            audio.requestAudioFocus(req)
            focusRequest = req
        } catch (_: Exception) {
        }
    }

    // Пока заблокировано — музыка/видео немые (будильник не трогаем)
    private fun enforceMute() {
        if (ui.musicOn) return   // звук разрешён на вкладке "Музыка"
        try {
            if (!audio.isStreamMute(AudioManager.STREAM_MUSIC)) {
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, 0)
                LockPolicy.setMutedByUs(this, true)
            }
        } catch (_: Exception) {
        }
    }

    private fun restoreSound() {
        if (LockPolicy.mutedByUs(this)) {
            try {
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0)
            } catch (_: Exception) {
            }
            LockPolicy.setMutedByUs(this, false)
        }
        focusRequest?.let {
            try { audio.abandonAudioFocusRequest(it) } catch (_: Exception) {}
        }
        focusRequest = null
    }

    private fun attachOwners(v: View) {
        v.setViewTreeLifecycleOwner(owner)
        v.setViewTreeViewModelStoreOwner(owner)
        v.setViewTreeSavedStateRegistryOwner(owner)
    }

    private fun composeView(content: @Composable () -> Unit): ComposeView =
        ComposeView(this).also {
            attachOwners(it)
            it.setContent(content)
        }

    private fun addLock() {
        if (lockView != null) return
        val compose = composeView {
            LockUi(ui, onDigit = { onDigit(it) }, onBack = { onBackspace() }, onExtra = { onExtra() },
                onWifi = { onWifi() }, onBluetooth = { onBluetooth() },
                onTap = { onTap() }, onBuy = { onBuy(it) },
                onMusicKey = { onMusicKey(it) }, onSound = { onSound(it) }, onVolume = { onVolume(it) })
        }
        // Корень, который съедает кнопку "Назад": без пароля экран не закрыть
        val v = object : FrameLayout(this@LockService) {
            override fun dispatchKeyEvent(event: KeyEvent): Boolean =
                if (event.keyCode == KeyEvent.KEYCODE_BACK) true else super.dispatchKeyEvent(event)
        }
        attachOwners(v)
        v.addView(compose)
        // Окно БЕЗ FLAG_NOT_FOCUSABLE — иначе "Назад" уходит в приложение под ним
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        // На весь экран: прячем строку состояния и кнопки навигации (если служба из карточки "Шторка" не включена)
        @Suppress("DEPRECATION")
        v.systemUiVisibility = android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
            android.view.View.SYSTEM_UI_FLAG_FULLSCREEN or
            android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        try {
            wm.addView(v, lp)
            lockView = v
            LockState.locked = true
            removeCharacter()   // чтобы персонаж снова оказался выше блока
        } catch (_: Exception) {
        }
    }

    // Убирает только окно блокировки (звук остаётся выключенным)
    private fun detachLockView() {
        lockView?.let {
            try { wm.removeView(it) } catch (_: Exception) {}
        }
        lockView = null
        saveClicker()
        LockState.locked = false
        ui.entered = ""
        ui.error = false
    }

    private fun removeLock() {
        detachLockView()
        ui.musicOn = false
        restoreSound()
    }

    private fun addBanner() {
        if (bannerView != null) return
        val v = composeView { BannerUi(ui) }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = android.view.Gravity.TOP or android.view.Gravity.END
        val d = resources.displayMetrics.density
        val sbId = resources.getIdentifier("status_bar_height", "dimen", "android")
        val statusBar = if (sbId > 0) resources.getDimensionPixelSize(sbId) else (24 * d).toInt()
        lp.x = (12 * d).toInt()
        lp.y = statusBar + (4 * d).toInt()
        try {
            wm.addView(v, lp)
            bannerView = v
        } catch (_: Exception) {
        }
    }

    private fun removeBanner() {
        bannerView?.let {
            try { wm.removeView(it) } catch (_: Exception) {}
        }
        bannerView = null
    }

    private fun onDigit(c: Char) {
        ui.error = false
        if (ui.entered.length >= Config.PASS_LEN) return
        ui.entered += c
        if (ui.entered.length == Config.PASS_LEN) {
            if (LockPolicy.check(this, ui.entered)) {
                LockPolicy.markUnlocked(this)
                removeLock()
            } else {
                ui.error = true
                ui.entered = ""
            }
        }
    }

    // "Ещё 10 минут": снимаем блокировку, в углу идёт таймер, по окончании блокируем снова
    private fun onExtra() {
        if (LockPolicy.startExtra(this)) {
            removeLock()
            onTick()
        }
    }

    private fun onBackspace() {
        ui.error = false
        if (ui.entered.isNotEmpty()) ui.entered = ui.entered.dropLast(1)
    }
}
