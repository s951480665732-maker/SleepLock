package com.sleeplock.app

import android.content.Context
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.security.SecureRandom
import java.time.LocalDateTime
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

enum class Phase { IDLE, EXTRA, LOCKED }

object LockPolicy {
    fun inLockWindow(sec: Int): Boolean =
        sec >= Config.LOCK_MIN * 60 && sec < Config.UNLOCK_MIN * 60

    // IDLE — не блокируем, EXTRA — идут "Ещё 10 минут" (таймер в углу), LOCKED — экран блокировки
    fun phase(c: Context, sec: Int): Phase = when {
        testActive(c) -> if (extraLeftSec(c) > 0) Phase.EXTRA else Phase.LOCKED
        !inLockWindow(sec) -> Phase.IDLE
        unlockedTonight(c) -> Phase.IDLE
        extraLeftSec(c) > 0 -> Phase.EXTRA
        else -> Phase.LOCKED
    }

    /**
     * Ключ "ночи" = дата, в которую наступает (или уже идёт) блокировка.
     * С 05:30 до 24:00 это завтрашняя дата, с 00:00 до 05:30 — сегодняшняя.
     */
    fun nightKey(): String {
        val now = LocalDateTime.now()
        val date =
            if (now.toLocalTime().toSecondOfDay() < Config.UNLOCK_MIN * 60) now.toLocalDate()
            else now.toLocalDate().plusDays(1)
        return date.toString()
    }

    private fun prefs(c: Context) = c.getSharedPreferences("sleeplock", Context.MODE_PRIVATE)

    private fun hash(salt: String, p: String): String =
        MessageDigest.getInstance("SHA-256")
            .digest((salt + p).toByteArray())
            .joinToString("") { "%02x".format(it) }

    // ---------- Пароль на ночь ----------

    fun zipFile(c: Context, key: String = nightKey()): File =
        File(File(c.filesDir, "shared"), "SleepLock_$key.zip")

    /**
     * Создаёт случайный пароль на ближайшую ночь (если его ещё нет).
     * В приложении хранится только соль + хэш, сам пароль лежит ТОЛЬКО в zip (password.txt).
     * Возвращает true, если пароль на эту ночь готов.
     */
    @Synchronized
    fun ensurePassword(c: Context): Boolean {
        val key = nightKey()
        val p = prefs(c)
        if (p.getString("pw_key", "") == key && zipFile(c, key).exists()) return true

        return try {
            val rnd = SecureRandom()
            val pass = (1..Config.PASS_LEN).joinToString("") { rnd.nextInt(10).toString() }
            val salt = ByteArray(8).also { rnd.nextBytes(it) }.joinToString("") { "%02x".format(it) }

            val file = zipFile(c, key)
            file.parentFile?.let { dir ->
                dir.mkdirs()
                // удаляем zip-ы прошлых ночей
                dir.listFiles()?.filter { it != file }?.forEach { it.delete() }
            }
            val text = "Sleep Lock\nНочь: $key\nПароль: $pass\n"
            ZipOutputStream(FileOutputStream(file)).use { z ->
                z.putNextEntry(ZipEntry("password.txt"))
                z.write(text.toByteArray(Charsets.UTF_8))
                z.closeEntry()
            }

            p.edit()
                .putString("pw_key", key)
                .putString("pw_salt", salt)
                .putString("pw_hash", hash(salt, pass))
                .apply()
            true
        } catch (_: Exception) {
            false
        }
    }

    fun check(c: Context, entered: String): Boolean {
        if (testActive(c)) return true   // тест: подойдёт любой пароль
        val p = prefs(c)
        if (p.getString("pw_key", "") != nightKey()) return false
        val salt = p.getString("pw_salt", null) ?: return false
        val saved = p.getString("pw_hash", null) ?: return false
        return MessageDigest.isEqual(hash(salt, entered).toByteArray(), saved.toByteArray())
    }

    fun zipUri(c: Context): Uri? {
        val f = zipFile(c)
        if (!f.exists()) return null
        return FileProvider.getUriForFile(c, "${c.packageName}.files", f)
    }

    // ---------- Разблокировка на эту ночь ----------

    // Если ввели пароль — до конца этой ночи больше не блокируем
    fun unlockedTonight(c: Context): Boolean =
        prefs(c).getString("unlocked_night", "") == nightKey()

    fun markUnlocked(c: Context) {
        prefs(c).edit().putString("unlocked_night", nightKey()).apply()
    }

    // ---------- "Ещё 10 минут" ----------

    fun extraAvailable(c: Context): Boolean {
        if (testActive(c)) return true   // в тесте кнопку можно жать сколько угодно
        val p = prefs(c)
        val used = if (p.getString("extra_night", "") == nightKey()) p.getInt("extra_count", 0) else 0
        return used < Config.EXTRA_PER_NIGHT
    }

    fun startExtra(c: Context): Boolean {
        if (testActive(c)) {
            // тест: отдельный таймер, настоящий счётчик "Ещё N минут" не трогаем
            prefs(c).edit()
                .putLong("test_extra_end_ms", System.currentTimeMillis() + Config.EXTRA_MIN * 60_000L)
                .apply()
            return true
        }
        if (!extraAvailable(c)) return false
        val p = prefs(c)
        val key = nightKey()
        val used = if (p.getString("extra_night", "") == key) p.getInt("extra_count", 0) else 0
        p.edit()
            .putString("extra_night", key)
            .putInt("extra_count", used + 1)
            .putLong("extra_end_ms", System.currentTimeMillis() + Config.EXTRA_MIN * 60_000L)
            .apply()
        return true
    }

    /** Сколько секунд осталось до конца дополнительных 10 минут (0 — нет). */
    fun extraLeftSec(c: Context): Int {
        val p = prefs(c)
        if (testActive(c)) {
            val t = (p.getLong("test_extra_end_ms", 0L) - System.currentTimeMillis()) / 1000
            return t.coerceAtLeast(0L).toInt()
        }
        if (p.getString("extra_night", "") != nightKey()) return 0
        val left = (p.getLong("extra_end_ms", 0L) - System.currentTimeMillis()) / 1000
        return left.coerceAtLeast(0L).toInt()
    }

    // ---------- Тест блокировки ----------

    /** Запускает тест: блокировка включается сразу, подходит любой пароль, через TEST_MIN минут сам закончится. */
    fun startTest(c: Context) {
        prefs(c).edit()
            .putLong("test_until_ms", System.currentTimeMillis() + Config.TEST_MIN * 60_000L)
            .putLong("test_extra_end_ms", 0L)
            .apply()
    }

    fun testActive(c: Context): Boolean =
        System.currentTimeMillis() < prefs(c).getLong("test_until_ms", 0L)

    fun endTest(c: Context) {
        prefs(c).edit()
            .putLong("test_until_ms", 0L)
            .putLong("test_extra_end_ms", 0L)
            .apply()
    }

    // ---------- Звук: заглушили ли мы его сами (чтобы вернуть после) ----------

    fun mutedByUs(c: Context): Boolean = prefs(c).getBoolean("muted_by_us", false)

    fun setMutedByUs(c: Context, v: Boolean) {
        prefs(c).edit().putBoolean("muted_by_us", v).apply()
    }
}
