package com.sleeplock.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import java.time.LocalTime

class MainActivity : ComponentActivity() {
    private var resumes by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { AppTheme { Home() } }
    }

    override fun onResume() {
        super.onResume()
        resumes++
        ContextCompat.startForegroundService(this, Intent(this, LockService::class.java))
    }

    @Composable
    private fun AppTheme(content: @Composable () -> Unit) {
        val dark = isSystemInDarkTheme()
        val ctx = LocalContext.current
        val scheme = when {
            Build.VERSION.SDK_INT >= 31 ->
                if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
            dark -> darkColorScheme()
            else -> lightColorScheme()
        }
        MaterialTheme(colorScheme = scheme, content = content)
    }

    @Composable
    private fun Home() {
        val ctx = LocalContext.current
        val sec by produceState(LocalTime.now().toSecondOfDay()) {
            while (true) {
                value = LocalTime.now().toSecondOfDay()
                delay(1000)
            }
        }
        val r = resumes
        val overlayOk = remember(r) { Settings.canDrawOverlays(ctx) }
        val notifOk = remember(r) {
            Build.VERSION.SDK_INT < 33 ||
                ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        }
        val batteryOk = remember(r) {
            ctx.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(ctx.packageName)
        }
        val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
            resumes++
        }

        val status = when (LockPolicy.phase(sec)) {
            Phase.IDLE -> "Следующая блокировка в ${Config.hm(Config.WARN_MIN)}"
            Phase.WARNING -> "Время на дела, блокировка в ${Config.hm(Config.LOCK_MIN)}"
            Phase.LOCKED -> "Заблокировано до ${Config.hm(Config.UNLOCK_MIN)}"
        }

        Surface(Modifier.fillMaxSize()) {
            Column(
                Modifier.fillMaxSize().systemBarsPadding().verticalScroll(rememberScrollState()).padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text("Sleep Lock", style = MaterialTheme.typography.headlineMedium)

                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(24.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            "%02d:%02d:%02d".format(sec / 3600, sec % 3600 / 60, sec % 60),
                            style = MaterialTheme.typography.displayLarge
                        )
                        Text(status, style = MaterialTheme.typography.titleMedium)
                    }
                }

                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Расписание", style = MaterialTheme.typography.titleMedium)
                        Text("${Config.hm(Config.WARN_MIN)} — предупреждение, ${Config.GRACE_MIN} минут на дела")
                        Text("${Config.hm(Config.LOCK_MIN)} — блокировка поверх всех окон")
                        Text("${Config.hm(Config.UNLOCK_MIN)} — автоматическая разблокировка")
                    }
                }

                PermissionCard("Поверх всех окон", overlayOk) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                }
                PermissionCard("Уведомления", notifOk) {
                    if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
                PermissionCard("Без ограничений батареи", batteryOk) {
                    startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
                }
            }
        }
    }

    @Composable
    private fun PermissionCard(title: String, ok: Boolean, onFix: () -> Unit) {
        ElevatedCard(Modifier.fillMaxWidth()) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(title, style = MaterialTheme.typography.titleMedium)
                    Text(
                        if (ok) "Включено" else "Нужно разрешить",
                        color = if (ok) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                    )
                }
                if (!ok) FilledTonalButton(onClick = onFix) { Text("Разрешить") }
            }
        }
    }
}
