package com.sleeplock.app

import android.content.Context
import java.security.MessageDigest
import java.time.LocalDate

enum class Phase { IDLE, WARNING, LOCKED }

object LockPolicy {
    fun phase(sec: Int): Phase = when {
        sec >= Config.WARN_MIN * 60 && sec < Config.LOCK_MIN * 60 -> Phase.WARNING
        sec >= Config.LOCK_MIN * 60 && sec < Config.UNLOCK_MIN * 60 -> Phase.LOCKED
        else -> Phase.IDLE
    }

    private fun hash(p: String): String {
        val md = MessageDigest.getInstance("SHA-256")
        return md.digest((Config.SALT + p).toByteArray()).joinToString("") { "%02x".format(it) }
    }

    fun check(p: String): Boolean = hash(p) == Config.HASH

    private fun prefs(c: Context) = c.getSharedPreferences("sleeplock", Context.MODE_PRIVATE)

    // Если ввели пароль — до конца этой ночи больше не блокируем
    fun unlockedTonight(c: Context): Boolean =
        prefs(c).getString("unlocked_day", "") == LocalDate.now().toString()

    fun markUnlocked(c: Context) {
        prefs(c).edit().putString("unlocked_day", LocalDate.now().toString()).apply()
    }
}
