package com.sleeplock.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.WindowManager
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.ComposeView
import androidx.core.app.ServiceCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import java.time.LocalTime

// Нужен, чтобы Compose работал внутри окна, созданного сервисом
class OverlayOwner : LifecycleOwner, ViewModelStoreOwner, SavedStateRegistryOwner {
    private val registry = LifecycleRegistry(this)
    private val controller = SavedStateRegistryController.create(this)
    private val store = ViewModelStore()

    override val lifecycle: Lifecycle get() = registry
    override val viewModelStore: ViewModelStore get() = store
    override val savedStateRegistry: SavedStateRegistry get() = controller.savedStateRegistry

    init {
        controller.performAttach()
        controller.performRestore(null)
    }

    fun start() {
        registry.currentState = Lifecycle.State.RESUMED
    }

    fun stop() {
        registry.currentState = Lifecycle.State.DESTROYED
        store.clear()
    }
}

class LockService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private val ui = UiState()
    private val owner = OverlayOwner()
    private lateinit var wm: WindowManager
    private var lockView: ComposeView? = null
    private var bannerView: ComposeView? = null

    private val tick = object : Runnable {
        override fun run() {
            onTick()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        owner.start()
        startAsForeground()
        handler.post(tick)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        removeLock()
        removeBanner()
        owner.stop()
        super.onDestroy()
    }

    private fun startAsForeground() {
        val channel = "sleeplock"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(channel, "Режим сна", NotificationManager.IMPORTANCE_LOW)
        )
        val n: Notification = Notification.Builder(this, channel)
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setContentTitle("Режим сна включён")
            .setContentText("Блокировка в ${Config.hm(Config.WARN_MIN)}, разблокировка в ${Config.hm(Config.UNLOCK_MIN)}")
            .setOngoing(true)
            .build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
    }

    private fun onTick() {
        ui.sec = LocalTime.now().toSecondOfDay()
        var phase = LockPolicy.phase(ui.sec)
        if (phase != Phase.IDLE && LockPolicy.unlockedTonight(this)) phase = Phase.IDLE
        if (!Settings.canDrawOverlays(this)) phase = Phase.IDLE

        if (phase == Phase.LOCKED) addLock() else removeLock()
        if (phase == Phase.WARNING) addBanner() else removeBanner()
    }

    private fun composeView(content: @Composable () -> Unit): ComposeView =
        ComposeView(this).also {
            it.setViewTreeLifecycleOwner(owner)
            it.setViewTreeViewModelStoreOwner(owner)
            it.setViewTreeSavedStateRegistryOwner(owner)
            it.setContent(content)
        }

    private fun addLock() {
        if (lockView != null) return
        val v = composeView {
            LockUi(ui, onDigit = { onDigit(it) }, onBack = { onBackspace() })
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        try {
            wm.addView(v, lp)
            lockView = v
        } catch (_: Exception) {
        }
    }

    private fun removeLock() {
        lockView?.let {
            try { wm.removeView(it) } catch (_: Exception) {}
        }
        lockView = null
        ui.entered = ""
        ui.error = false
    }

    private fun addBanner() {
        if (bannerView != null) return
        val v = composeView { BannerUi(ui) }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = android.view.Gravity.TOP
        lp.y = (48 * resources.displayMetrics.density).toInt()
        try {
            wm.addView(v, lp)
            bannerView = v
        } catch (_: Exception) {
        }
    }

    private fun removeBanner() {
        bannerView?.let {
            try { wm.removeView(it) } catch (_: Exception) {}
        }
        bannerView = null
    }

    private fun onDigit(c: Char) {
        ui.error = false
        if (ui.entered.length >= Config.PASS_LEN) return
        ui.entered += c
        if (ui.entered.length == Config.PASS_LEN) {
            if (LockPolicy.check(ui.entered)) {
                LockPolicy.markUnlocked(this)
                removeLock()
            } else {
                ui.error = true
                ui.entered = ""
            }
        }
    }

    private fun onBackspace() {
        ui.error = false
        if (ui.entered.isNotEmpty()) ui.entered = ui.entered.dropLast(1)
    }
}
