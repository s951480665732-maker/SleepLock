package com.sleeplock.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.AlarmManager
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.bluetooth.BluetoothManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.PixelFormat
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.widget.FrameLayout
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.ComposeView
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import java.time.LocalTime

// Нужен, чтобы Compose работал внутри окна, созданного сервисом
class OverlayOwner : LifecycleOwner, ViewModelStoreOwner, SavedStateRegistryOwner {
    private val registry = LifecycleRegistry(this)
    private val controller = SavedStateRegistryController.create(this)
    private val store = ViewModelStore()

    override val lifecycle: Lifecycle get() = registry
    override val viewModelStore: ViewModelStore get() = store
    override val savedStateRegistry: SavedStateRegistry get() = controller.savedStateRegistry

    init {
        controller.performAttach()
        controller.performRestore(null)
    }

    fun start() {
        registry.currentState = Lifecycle.State.RESUMED
    }

    fun stop() {
        registry.currentState = Lifecycle.State.DESTROYED
        store.clear()
    }
}

class LockService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private val ui = UiState()
    private val owner = OverlayOwner()
    private lateinit var wm: WindowManager
    private lateinit var audio: AudioManager
    private var lockView: View? = null
    private var bannerView: ComposeView? = null
    private var focusRequest: AudioFocusRequest? = null
    private var ensuredKey = ""
    private var mediaController: MediaController? = null
    private var artKey = ""
    private var artTries = 0
    private var panelUntil = 0L   // до этого момента блокировка временно снята (окно Wi-Fi/Bluetooth)

    private var healthTicks = 0
    private var clickDirty = false
    private var clickTicks = 0

    private val tick = object : Runnable {
        override fun run() {
            healthCheck()   // раз в секунду: всё ли на месте (пока телефон заблокирован — пропускаем)
            try {
                onTick()
            } catch (_: Exception) {
            }
            clickerTick()
            readVolume()
            readMedia()
            handler.postDelayed(this, 1000)
        }
    }

    // Экран включили / разблокировали — проверяем сразу, не ждём секунду
    private val wake = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            handler.removeCallbacks(tick)
            handler.post(tick)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        audio = getSystemService(AUDIO_SERVICE) as AudioManager
        owner.start()
        Accent.load(this)
        Clicker.load(this, ui)
        startAsForeground()
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_USER_PRESENT)
            addAction(Intent.ACTION_SCREEN_ON)
        }
        ContextCompat.registerReceiver(this, wake, f, ContextCompat.RECEIVER_NOT_EXPORTED)
        Watch.start(this, GuardService::class.java)
        handler.post(tick)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try { unregisterReceiver(wake) } catch (_: Exception) {}
        removeLock()
        removeBanner()
        owner.stop()
        scheduleRestart()   // если сервис остановили (например, из диспетчера задач) — поднимаем снова
        super.onDestroy()
    }

    // Смахнули приложение из последних — сервис должен жить дальше
    override fun onTaskRemoved(rootIntent: Intent?) {
        scheduleRestart()
        super.onTaskRemoved(rootIntent)
    }

    private fun scheduleRestart() {
        try {
            val pi = PendingIntent.getBroadcast(
                this, 7, Intent(this, BootReceiver::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            getSystemService(AlarmManager::class.java).setAndAllowWhileIdle(
                AlarmManager.ELAPSED_REALTIME_WAKEUP,
                SystemClock.elapsedRealtime() + 1500,
                pi
            )
        } catch (_: Exception) {
        }
    }

    private fun startAsForeground() = Watch.foreground(this)

    // Проверка "всё ли хорошо" — раз в секунду. Пока телефон заблокирован, не проверяем (до разблокировки).
    private fun healthCheck() {
        if (Watch.deviceLocked(this)) return
        try {
            // 1. Страж (другой процесс) жив? Если закрыт — запускаем
            if (!Watch.isRunning(this, GuardService::class.java)) {
                Watch.start(this, GuardService::class.java)
            }

            // 2. Система могла убрать наши окна — тогда onTick() создаст их заново
            if (lockView?.isAttachedToWindow == false) detachLockView()
            if (bannerView?.isAttachedToWindow == false) removeBanner()

            // 3. Раз в 30 секунд: уведомление на месте, пароль на ночь и zip в порядке
            if (++healthTicks % 30 == 0) {
                startAsForeground()
                LockPolicy.ensurePassword(this)
            }
        } catch (_: Exception) {
        }
    }

    // ---------- Музыка ----------
    private fun onMusicKey(code: Int) {
        try {
            val t = SystemClock.uptimeMillis()
            audio.dispatchMediaKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_DOWN, code, 0))
            audio.dispatchMediaKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_UP, code, 0))
        } catch (_: Exception) {
        }
    }

    private fun onSound(on: Boolean) {
        ui.musicOn = on
        if (on) {
            try {
                if (audio.isStreamMute(AudioManager.STREAM_MUSIC)) {
                    audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0)
                }
            } catch (_: Exception) {
            }
            LockPolicy.setMutedByUs(this, false)
            focusRequest?.let {
                try { audio.abandonAudioFocusRequest(it) } catch (_: Exception) {}
            }
            focusRequest = null
        } else {
            enforceMute()
            takeAudioFocus()
        }
        readVolume()
    }

    // Название трека, позиция и перемотка — через активную медиасессию (нужен «Доступ к музыке»)
    private fun readMedia() {
        if (lockView == null) return
        try {
            val msm = getSystemService(MediaSessionManager::class.java)
            val list = msm.getActiveSessions(ComponentName(this, MediaListener::class.java))
            ui.mAccess = true
            val c = list.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
                ?: list.firstOrNull()
            mediaController = c
            if (c == null) {
                ui.mTitle = ""
                ui.mArtist = ""
                ui.mDur = 0L
                ui.mPos = 0L
                ui.mPlaying = false
                ui.mArt = null
                artKey = ""
                return
            }
            val md = c.metadata
            ui.mTitle = md?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: ""
            ui.mArtist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST)
                ?: md?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: ""
            val dur = md?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
            // Обложка: при смене трека сбрасываем, пробуем достать (несколько попыток — плеер может прислать позже)
            val key = "${ui.mTitle}|${ui.mArtist}|$dur"
            if (key != artKey) {
                artKey = key
                artTries = 0
                ui.mArt = null
            }
            if (ui.mArt == null && artTries < 5) {
                artTries++
                ui.mArt = loadArt(md)?.asImageBitmap()
            }
            val st = c.playbackState
            var pos = st?.position ?: 0L
            val playing = st?.state == PlaybackState.STATE_PLAYING
            if (st != null && playing && pos >= 0) {
                pos += ((SystemClock.elapsedRealtime() - st.lastPositionUpdateTime) * st.playbackSpeed).toLong()
            }
            ui.mDur = dur.coerceAtLeast(0L)
            ui.mPos = if (ui.mDur > 0) pos.coerceIn(0L, ui.mDur) else 0L
            ui.mPlaying = playing
        } catch (_: SecurityException) {
            ui.mAccess = false
            mediaController = null
        } catch (_: Exception) {
        }
    }

    private fun loadArt(md: MediaMetadata?): Bitmap? {
        if (md == null) return null
        var bmp: Bitmap? = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: md.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: md.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        if (bmp == null) {
            val keys = listOf(
                MediaMetadata.METADATA_KEY_ALBUM_ART_URI,
                MediaMetadata.METADATA_KEY_ART_URI,
                MediaMetadata.METADATA_KEY_DISPLAY_ICON_URI
            )
            for (k in keys) {
                val u = md.getString(k)
                if (u.isNullOrEmpty()) continue
                try {
                    val uri = Uri.parse(u)
                    if (uri.scheme == "content" || uri.scheme == "file" || uri.scheme == "android.resource") {
                        contentResolver.openInputStream(uri)?.use { bmp = BitmapFactory.decodeStream(it) }
                    }
                } catch (_: Exception) {
                }
                if (bmp != null) break
            }
        }
        val b = bmp ?: return null
        return try {
            // копия, чтобы плеер не мог «выдернуть» картинку, и не больше 600 px
            val side = maxOf(b.width, b.height)
            if (side > 600) {
                val k = 600f / side
                Bitmap.createScaledBitmap(b, (b.width * k).toInt().coerceAtLeast(1), (b.height * k).toInt().coerceAtLeast(1), true)
            } else {
                b.copy(Bitmap.Config.ARGB_8888, false)
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun onSeek(frac: Float) {
        val c = mediaController ?: return
        if (ui.mDur <= 0) return
        val target = (ui.mDur * frac.coerceIn(0f, 1f)).toLong()
        try {
            c.transportControls.seekTo(target)
        } catch (_: Exception) {
        }
        ui.mPos = target
    }

    private fun onVolume(v: Int) {
        try {
            audio.setStreamVolume(AudioManager.STREAM_MUSIC, v, 0)
            ui.vol = v
        } catch (_: Exception) {
        }
    }

    private fun readVolume() {
        if (lockView == null) return
        try {
            ui.volMax = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            ui.vol = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
        } catch (_: Exception) {
        }
    }

    // ---------- Кликер ----------
    private fun onTap() {
        ui.score += Clicker.perClick(ui.levels)
        clickDirty = true
    }

    private fun onBuy(i: Int) {
        val cost = Clicker.cost(i, ui.levels[i])
        if (ui.score >= cost) {
            ui.score -= cost
            ui.levels[i] = ui.levels[i] + 1
            clickDirty = true
            saveClicker()
        }
    }

    // Раз в секунду, пока экран блокировки на экране, капает доход от автокликеров
    private fun clickerTick() {
        if (lockView != null) {
            val ps = Clicker.perSec(ui.levels)
            if (ps > 0) {
                ui.score += ps
                clickDirty = true
            }
        }
        if (clickDirty && ++clickTicks >= 10) saveClicker()
    }

    private fun saveClicker() {
        if (!clickDirty) return
        Clicker.save(this, ui)
        clickDirty = false
        clickTicks = 0
    }

    private fun onTick() {
        ui.sec = LocalTime.now().toSecondOfDay()

        // Случайный пароль на ближайшую ночь (лежит только в zip)
        val key = LockPolicy.nightKey()
        if (key != ensuredKey && LockPolicy.ensurePassword(this)) ensuredKey = key

        if (ui.battery < 0 || ui.sec % 10 == 0) readBattery()

        ui.testMode = LockPolicy.testActive(this)
        ui.extraLeft = LockPolicy.extraLeftSec(this)
        ui.extraAvailable = LockPolicy.extraAvailable(this)

        var phase = LockPolicy.phase(this, ui.sec)
        if (!Settings.canDrawOverlays(this)) phase = Phase.IDLE

        if (phase == Phase.LOCKED) {
            if (lockView == null && SystemClock.elapsedRealtime() >= panelUntil) {
                addLock()
                if (lockView != null) onLocked()   // заодно выкидывает из открытых настроек
            }
            if (lockView != null) enforceMute()
            readRadios()
        } else {
            removeLock()
        }
        if (phase == Phase.EXTRA) addBanner() else removeBanner()
    }

    private fun readRadios() {
        try {
            ui.wifiOn = (applicationContext.getSystemService(WIFI_SERVICE) as WifiManager).isWifiEnabled
        } catch (_: Exception) {
        }
        try {
            ui.btOn = getSystemService(BluetoothManager::class.java)?.adapter?.isEnabled == true
        } catch (_: Exception) {
        }
    }

    // Android не даёт приложениям включать Wi-Fi/Bluetooth напрямую, поэтому открываем
    // системное окно и на PANEL_SEC секунд прячем блокировку. Потом она возвращается.
    private fun openSystemRadio(intent: Intent) {
        try {
            startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            panelUntil = SystemClock.elapsedRealtime() + Config.PANEL_SEC * 1000L
            detachLockView()
        } catch (_: Exception) {
        }
    }

    private fun onWifi() {
        openSystemRadio(
            if (Build.VERSION.SDK_INT >= 29) Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)
            else Intent(Settings.ACTION_WIFI_SETTINGS)
        )
    }

    private fun onBluetooth() {
        openSystemRadio(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
    }

    private fun readBattery() {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        if (level >= 0 && scale > 0) ui.battery = level * 100 / scale
        val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        ui.charging = st == BatteryManager.BATTERY_STATUS_CHARGING ||
            st == BatteryManager.BATTERY_STATUS_FULL
    }

    // ---------- Момент блокировки: ставим на паузу, глушим звук, выходим из приложения ----------

    private fun onLocked() {
        pauseMedia()
        takeAudioFocus()
        enforceMute()
        // Уходим на домашний экран — из приложения, в котором был человек.
        // Запуск из фона разрешён, т.к. у нас есть "Поверх всех окон".
        handler.postDelayed({ goHome() }, 400)
    }

    private fun goHome() {
        try {
            startActivity(
                Intent(Intent.ACTION_MAIN)
                    .addCategory(Intent.CATEGORY_HOME)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (_: Exception) {
        }
    }

    private fun pauseMedia() {
        try {
            val t = SystemClock.uptimeMillis()
            audio.dispatchMediaKeyEvent(
                KeyEvent(t, t, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PAUSE, 0)
            )
            audio.dispatchMediaKeyEvent(
                KeyEvent(t, t, KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PAUSE, 0)
            )
        } catch (_: Exception) {
        }
    }

    private fun takeAudioFocus() {
        if (focusRequest != null) return
        try {
            val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setOnAudioFocusChangeListener { _ -> }
                .build()
            audio.requestAudioFocus(req)
            focusRequest = req
        } catch (_: Exception) {
        }
    }

    // Пока заблокировано — музыка/видео немые (будильник не трогаем)
    private fun enforceMute() {
        if (ui.musicOn) return   // звук разрешён на вкладке "Музыка"
        try {
            if (!audio.isStreamMute(AudioManager.STREAM_MUSIC)) {
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, 0)
                LockPolicy.setMutedByUs(this, true)
            }
        } catch (_: Exception) {
        }
    }

    private fun restoreSound() {
        if (LockPolicy.mutedByUs(this)) {
            try {
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0)
            } catch (_: Exception) {
            }
            LockPolicy.setMutedByUs(this, false)
        }
        focusRequest?.let {
            try { audio.abandonAudioFocusRequest(it) } catch (_: Exception) {}
        }
        focusRequest = null
    }

    private fun attachOwners(v: View) {
        v.setViewTreeLifecycleOwner(owner)
        v.setViewTreeViewModelStoreOwner(owner)
        v.setViewTreeSavedStateRegistryOwner(owner)
    }

    private fun composeView(content: @Composable () -> Unit): ComposeView =
        ComposeView(this).also {
            attachOwners(it)
            it.setContent(content)
        }

    private fun addLock() {
        if (lockView != null) return
        val compose = composeView {
            LockUi(ui, onDigit = { onDigit(it) }, onBack = { onBackspace() }, onExtra = { onExtra() },
                onWifi = { onWifi() }, onBluetooth = { onBluetooth() },
                onTap = { onTap() }, onBuy = { onBuy(it) },
                onMusicKey = { onMusicKey(it) }, onSound = { onSound(it) }, onVolume = { onVolume(it) },
                onSeek = { onSeek(it) })
        }
        // Корень, который съедает кнопку "Назад": без пароля экран не закрыть
        val v = object : FrameLayout(this@LockService) {
            override fun dispatchKeyEvent(event: KeyEvent): Boolean =
                if (event.keyCode == KeyEvent.KEYCODE_BACK) true else super.dispatchKeyEvent(event)
        }
        attachOwners(v)
        v.addView(compose)
        // Окно БЕЗ FLAG_NOT_FOCUSABLE — иначе "Назад" уходит в приложение под ним
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        // На весь экран: прячем строку состояния и кнопки навигации (если служба из карточки "Шторка" не включена)
        @Suppress("DEPRECATION")
        v.systemUiVisibility = android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
            android.view.View.SYSTEM_UI_FLAG_FULLSCREEN or
            android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        try {
            wm.addView(v, lp)
            lockView = v
            LockState.locked = true
        } catch (_: Exception) {
        }
    }

    // Убирает только окно блокировки (звук остаётся выключенным)
    private fun detachLockView() {
        lockView?.let {
            try { wm.removeView(it) } catch (_: Exception) {}
        }
        lockView = null
        saveClicker()
        LockState.locked = false
        ui.entered = ""
        ui.error = false
    }

    private fun removeLock() {
        detachLockView()
        ui.musicOn = false
        restoreSound()
    }

    private fun addBanner() {
        if (bannerView != null) return
        val v = composeView { BannerUi(ui) }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = android.view.Gravity.TOP or android.view.Gravity.END
        val d = resources.displayMetrics.density
        val sbId = resources.getIdentifier("status_bar_height", "dimen", "android")
        val statusBar = if (sbId > 0) resources.getDimensionPixelSize(sbId) else (24 * d).toInt()
        lp.x = (12 * d).toInt()
        lp.y = statusBar + (4 * d).toInt()
        try {
            wm.addView(v, lp)
            bannerView = v
        } catch (_: Exception) {
        }
    }

    private fun removeBanner() {
        bannerView?.let {
            try { wm.removeView(it) } catch (_: Exception) {}
        }
        bannerView = null
    }

    private fun onDigit(c: Char) {
        ui.error = false
        if (ui.entered.length >= Config.PASS_LEN) return
        ui.entered += c
        if (ui.entered.length == Config.PASS_LEN) {
            if (LockPolicy.check(this, ui.entered)) {
                // тест просто заканчивается, а настоящая ночь отмечается разблокированной
                if (LockPolicy.testActive(this)) LockPolicy.endTest(this)
                else LockPolicy.markUnlocked(this)
                removeLock()
            } else {
                ui.error = true
                ui.entered = ""
            }
        }
    }

    // "Ещё 10 минут": снимаем блокировку, в углу идёт таймер, по окончании блокируем снова
    private fun onExtra() {
        if (LockPolicy.startExtra(this)) {
            removeLock()
            onTick()
        }
    }

    private fun onBackspace() {
        ui.error = false
        if (ui.entered.isNotEmpty()) ui.entered = ui.entered.dropLast(1)
    }
}
