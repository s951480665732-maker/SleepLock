package com.sleeplock.app

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

class UiState {
    var sec by mutableIntStateOf(0)
    var entered by mutableStateOf("")
    var error by mutableStateOf(false)
}

private val NightColors = darkColorScheme(
    primary = Color(0xFFB8C4FF),
    onPrimary = Color(0xFF1B2D7A),
    primaryContainer = Color(0xFF334290),
    onPrimaryContainer = Color(0xFFDDE1FF),
    secondaryContainer = Color(0xFF2F3550),
    onSecondaryContainer = Color(0xFFDDE1FF),
    background = Color(0xFF0F1117),
    onBackground = Color(0xFFE3E2E9),
    surface = Color(0xFF0F1117),
    onSurface = Color(0xFFE3E2E9),
    error = Color(0xFFFFB4AB)
)

@Composable
fun NightTheme(content: @Composable () -> Unit) =
    MaterialTheme(colorScheme = NightColors, content = content)

@Composable
fun BannerUi(ui: UiState) {
    NightTheme {
        val left = (Config.LOCK_MIN * 60 - ui.sec).coerceAtLeast(0)
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
        ) {
            Column(Modifier.padding(16.dp)) {
                Text("Пора закругляться", style = MaterialTheme.typography.titleMedium)
                Text(
                    "Блокировка через %d:%02d".format(left / 60, left % 60),
                    style = MaterialTheme.typography.headlineSmall
                )
            }
        }
    }
}

@Composable
fun LockUi(ui: UiState, onDigit: (Char) -> Unit, onBack: () -> Unit) {
    NightTheme {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            val left = (Config.UNLOCK_MIN * 60 - ui.sec).coerceAtLeast(0)
            Column(
                Modifier.fillMaxSize().padding(start = 24.dp, end = 24.dp, top = 56.dp, bottom = 32.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    "%02d:%02d".format(ui.sec / 3600, ui.sec % 3600 / 60),
                    style = MaterialTheme.typography.displayLarge
                )
                Text(
                    "Пора спать. Разблокировка в ${Config.hm(Config.UNLOCK_MIN)}",
                    style = MaterialTheme.typography.titleMedium
                )
                Text(
                    "Осталось %d ч %02d мин".format(left / 3600, left % 3600 / 60),
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(Modifier.weight(1f))
                Dots(ui.entered.length, Config.PASS_LEN, ui.error)
                Text(
                    if (ui.error) "Неверный пароль" else " ",
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(vertical = 8.dp)
                )
                listOf("123", "456", "789").forEach { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        row.forEach { ch -> Key(ch.toString(), Modifier.weight(1f)) { onDigit(ch) } }
                    }
                    Spacer(Modifier.height(12.dp))
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Spacer(Modifier.weight(1f))
                    Key("0", Modifier.weight(1f)) { onDigit('0') }
                    Key("⌫", Modifier.weight(1f)) { onBack() }
                }
            }
        }
    }
}

@Composable
private fun Key(label: String, modifier: Modifier, onClick: () -> Unit) {
    FilledTonalButton(onClick = onClick, modifier = modifier.height(68.dp)) {
        Text(label, style = MaterialTheme.typography.headlineSmall)
    }
}

@Composable
private fun Dots(count: Int, total: Int, error: Boolean) {
    val color = if (error) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        repeat(total) { i ->
            Box(
                Modifier
                    .size(14.dp)
                    .clip(CircleShape)
                    .background(if (i < count) color else Color.Transparent)
                    .border(2.dp, color, CircleShape)
            )
        }
    }
}
