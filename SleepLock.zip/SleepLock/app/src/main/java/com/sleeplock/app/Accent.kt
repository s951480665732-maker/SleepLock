package com.sleeplock.app

import android.content.Context
import androidx.compose.material3.ColorScheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp

/** Цвет акцента. 0 = цвета системы (Material You). Состояние общее для приложения и экрана блокировки. */
object Accent {
    var argb by mutableIntStateOf(0)
        private set

    val presets: List<Int> = listOf(
        0xFF7C4DFF, 0xFF2979FF, 0xFF00B8D4, 0xFF00C853, 0xFFFFD600,
        0xFFFF9100, 0xFFFF1744, 0xFFF50057, 0xFFAA00FF, 0xFF8D6E63
    ).map { it.toInt() }

    private fun prefs(c: Context) = c.getSharedPreferences("accent", Context.MODE_PRIVATE)

    fun load(c: Context) {
        argb = prefs(c).getInt("argb", 0)
    }

    fun set(c: Context, v: Int) {
        argb = v
        prefs(c).edit().putInt("argb", v).apply()
    }
}

/** Берёт цветовую схему (системную или запасную) и перекрашивает акцентные роли под выбранный цвет. */
fun accentScheme(seed: Color, dark: Boolean, base: ColorScheme): ColorScheme {
    val white = Color.White
    val black = Color.Black
    return if (dark) {
        val primary = lerp(seed, white, 0.35f)
        base.copy(
            primary = primary,
            onPrimary = lerp(seed, black, 0.75f),
            primaryContainer = lerp(seed, black, 0.55f),
            onPrimaryContainer = lerp(seed, white, 0.8f),
            secondary = lerp(seed, white, 0.45f),
            onSecondary = lerp(seed, black, 0.75f),
            secondaryContainer = lerp(seed, black, 0.72f),
            onSecondaryContainer = lerp(seed, white, 0.8f),
            surfaceTint = primary,
            surfaceContainer = lerp(base.surfaceContainer, seed, 0.12f)
        )
    } else {
        val primary = lerp(seed, black, 0.15f)
        base.copy(
            primary = primary,
            onPrimary = white,
            primaryContainer = lerp(seed, white, 0.8f),
            onPrimaryContainer = lerp(seed, black, 0.7f),
            secondary = lerp(seed, black, 0.3f),
            onSecondary = white,
            secondaryContainer = lerp(seed, white, 0.85f),
            onSecondaryContainer = lerp(seed, black, 0.7f),
            surfaceTint = primary,
            surfaceContainer = lerp(base.surfaceContainer, seed, 0.08f)
        )
    }
}
