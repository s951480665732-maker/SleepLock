package com.sleeplock.app

import android.view.KeyEvent
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.roundToInt
import kotlin.math.sin

private fun fmt(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}

@Composable
fun MusicTab(
    ui: UiState,
    onKey: (Int) -> Unit,
    onSound: (Boolean) -> Unit,
    onVolume: (Int) -> Unit,
    onSeek: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 24.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Обложка трека
        Box(
            Modifier
                .size(180.dp)
                .clip(RoundedCornerShape(28.dp))
                .background(MaterialTheme.colorScheme.secondaryContainer),
            contentAlignment = Alignment.Center
        ) {
            val art = ui.mArt
            if (art != null) {
                Image(
                    bitmap = art,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Text(
                    "♪",
                    style = MaterialTheme.typography.displayLarge,
                    color = MaterialTheme.colorScheme.onSecondaryContainer
                )
            }
        }
        Spacer(Modifier.height(16.dp))
        Text(
            ui.mTitle.ifEmpty { "Ничего не играет" },
            style = MaterialTheme.typography.titleLarge,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center
        )
        if (ui.mArtist.isNotEmpty()) {
            Text(
                ui.mArtist,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        if (!ui.mAccess) {
            Spacer(Modifier.height(8.dp))
            Text(
                "Чтобы видеть трек и перематывать, включи «Доступ к музыке» в приложении Sleep Lock",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.error,
                textAlign = TextAlign.Center
            )
        }
        Spacer(Modifier.height(20.dp))

        val dur = ui.mDur
        val pos = if (dur > 0) ui.mPos.coerceIn(0L, dur) else 0L
        WavySeek(
            frac = if (dur > 0) pos.toFloat() / dur else 0f,
            playing = ui.mPlaying,
            enabled = dur > 0,
            onSeek = onSeek
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(fmt(pos), style = MaterialTheme.typography.labelMedium)
            Text(
                if (dur > 0) "осталось ${fmt(dur - pos)}" else "",
                style = MaterialTheme.typography.labelMedium
            )
        }

        Spacer(Modifier.height(20.dp))
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            MusicKey("⏮", Modifier.weight(1f), big = false) { onKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS) }
            MusicKey(if (ui.mPlaying) "⏸" else "▶", Modifier.weight(1.3f), big = true) {
                onKey(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
            }
            MusicKey("⏭", Modifier.weight(1f), big = false) { onKey(KeyEvent.KEYCODE_MEDIA_NEXT) }
        }

        Spacer(Modifier.height(20.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Звук музыки", style = MaterialTheme.typography.titleMedium)
                Text(
                    if (ui.musicOn) "Включён до разблокировки" else "Выключен: музыка и видео немые",
                    style = MaterialTheme.typography.bodySmall
                )
            }
            Switch(checked = ui.musicOn, onCheckedChange = onSound)
        }
        Spacer(Modifier.height(8.dp))
        Text("Громкость", style = MaterialTheme.typography.titleSmall)
        if (ui.volMax > 0) {
            Slider(
                value = ui.vol.toFloat(),
                onValueChange = { onVolume(it.roundToInt()) },
                valueRange = 0f..ui.volMax.toFloat(),
                steps = (ui.volMax - 1).coerceAtLeast(0),
                enabled = ui.musicOn
            )
        }
    }
}

/**
 * Полоса перемотки как в плеере на фото: пройденная часть — волна, ползунок — вертикальная палочка,
 * дальше прямая линия с точкой на конце. Можно тапнуть или потянуть.
 */
@Composable
fun WavySeek(frac: Float, playing: Boolean, enabled: Boolean, onSeek: (Float) -> Unit, modifier: Modifier = Modifier) {
    var dragFrac by remember { mutableStateOf<Float?>(null) }
    var wPx by remember { mutableFloatStateOf(1f) }
    val smooth by animateFloatAsState(
        frac,
        animationSpec = if (playing) tween(900, easing = LinearEasing) else snap(),
        label = "pos"
    )
    val shown = (dragFrac ?: smooth).coerceIn(0f, 1f)
    val color = MaterialTheme.colorScheme.primary
    val track = color.copy(alpha = 0.35f)
    val phase: Float by rememberInfiniteTransition(label = "wave").animateFloat(
        initialValue = 0f,
        targetValue = (2 * PI).toFloat(),
        animationSpec = infiniteRepeatable(tween(1600, easing = LinearEasing)),
        label = "phase"
    )

    Canvas(
        modifier
            .fillMaxWidth()
            .height(36.dp)
            .onSizeChanged { wPx = it.width.toFloat().coerceAtLeast(1f) }
            .pointerInput(enabled) {
                if (enabled) detectTapGestures { o -> onSeek((o.x / wPx).coerceIn(0f, 1f)) }
            }
            .pointerInput(enabled) {
                if (enabled) detectHorizontalDragGestures(
                    onDragStart = { o -> dragFrac = (o.x / wPx).coerceIn(0f, 1f) },
                    onDragEnd = {
                        dragFrac?.let(onSeek)
                        dragFrac = null
                    },
                    onDragCancel = { dragFrac = null },
                    onHorizontalDrag = { change, _ -> dragFrac = (change.position.x / wPx).coerceIn(0f, 1f) }
                )
            }
    ) {
        val cy = size.height / 2
        val x = size.width * shown
        val amp = if (playing) 3.dp.toPx() else 0f
        val wl = 22.dp.toPx()
        val sw = 4.dp.toPx()

        // пройденная часть — волна
        val path = Path()
        path.moveTo(0f, cy + amp * sin(-phase))
        var px = 2f
        while (px < x) {
            path.lineTo(px, cy + amp * sin((2 * PI * px / wl).toFloat() - phase))
            px += 2f
        }
        path.lineTo(x, cy + amp * sin((2 * PI * x / wl).toFloat() - phase))
        drawPath(path, color, style = Stroke(width = sw, cap = StrokeCap.Round, join = StrokeJoin.Round))

        // оставшаяся часть — прямая линия с точкой на конце
        val gap = 6.dp.toPx()
        if (x + gap < size.width) {
            drawLine(track, Offset(x + gap, cy), Offset(size.width - 3.dp.toPx(), cy), strokeWidth = sw, cap = StrokeCap.Round)
        }
        drawCircle(color, radius = 2.dp.toPx(), center = Offset(size.width - 3.dp.toPx(), cy))

        // ползунок — вертикальная палочка
        drawRoundRect(
            color,
            topLeft = Offset(x - 2.dp.toPx(), cy - 12.dp.toPx()),
            size = Size(4.dp.toPx(), 24.dp.toPx()),
            cornerRadius = CornerRadius(2.dp.toPx())
        )
    }
}

@Composable
private fun MusicKey(label: String, modifier: Modifier, big: Boolean, onClick: () -> Unit) {
    val m = modifier.height(if (big) 72.dp else 60.dp)
    if (big) {
        Button(onClick = onClick, modifier = m, shape = RoundedCornerShape(24.dp)) {
            Text(label, style = MaterialTheme.typography.headlineMedium)
        }
    } else {
        FilledTonalButton(onClick = onClick, modifier = m, shape = RoundedCornerShape(24.dp)) {
            Text(label, style = MaterialTheme.typography.headlineSmall)
        }
    }
}
