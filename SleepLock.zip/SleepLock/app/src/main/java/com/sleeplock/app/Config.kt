package com.sleeplock.app

object Config {
    // Всё в минутах от полуночи — можно менять для теста
    const val WARN_MIN = 30      // 00:30 — предупреждение
    const val GRACE_MIN = 10     // 10 минут на дела
    const val LOCK_MIN = WARN_MIN + GRACE_MIN
    const val UNLOCK_MIN = 330   // 05:30 — авто-разблокировка

    const val PASS_LEN = 8
    const val SALT = "60db9866c7f7de11"
    const val HASH = "9a28339a55b02f0986408fdd60ceec202992c73f10246546a335faaec1821259"

    fun hm(min: Int): String = "%02d:%02d".format(min / 60, min % 60)
}
