package com.sleeplock.app

object Config {
    // Всё в минутах от полуночи — можно менять для теста
    const val LOCK_MIN = 30      // 00:30 (12:30 AM) — блокировка
    const val UNLOCK_MIN = 330   // 05:30 — авто-разблокировка

    const val EXTRA_MIN = 10         // кнопка "Ещё 10 минут"
    const val EXTRA_PER_NIGHT = 1    // сколько раз за ночь можно нажать

    const val PASS_LEN = 8       // длина случайного пароля (цифры)

    fun hm(min: Int): String = "%02d:%02d".format(min / 60, min % 60)
}
